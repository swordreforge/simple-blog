! function() {
    let e = [],
        t = 1;
    const n = 20;
    let a = 0,
        i = window.selectedAttachments || new Set;
    window.currentAction = window.currentAction || null, window.currentItemId = window.currentItemId || null, window.selectedAttachments = i;
    const o = {
        uploadBtn: document.getElementById("amUploadBtn"),
        emptyUploadBtn: document.getElementById("amEmptyUploadBtn"),
        refreshBtn: document.getElementById("amRefreshBtn"),
        fileTypeFilter: document.getElementById("amFileTypeFilter"),
        visibilityFilter: document.getElementById("amVisibilityFilter"),
        passageFilter: document.getElementById("amPassageFilter"),
        searchInput: document.getElementById("amSearchInput"),
        tableBody: document.getElementById("attachmentsTableBody"),
        selectAll: document.getElementById("amSelectAll"),
        totalCount: document.getElementById("amTotalCount"),
        totalSize: document.getElementById("amTotalSize"),
        imageCount: document.getElementById("amImageCount"),
        documentCount: document.getElementById("amDocumentCount"),
        paginationContainer: document.getElementById("amPaginationContainer"),
        paginationInfo: document.getElementById("amPaginationInfo"),
        prevPageBtn: document.getElementById("amPrevPageBtn"),
        nextPageBtn: document.getElementById("amNextPageBtn"),
        paginationPages: document.getElementById("amPaginationPages"),
        batchActions: document.getElementById("amBatchActions"),
        selectedCount: document.getElementById("amSelectedCount"),
        batchDeleteBtn: document.getElementById("amBatchDeleteBtn"),
        batchSetPublicBtn: document.getElementById("amBatchSetPublicBtn"),
        batchSetPrivateBtn: document.getElementById("amBatchSetPrivateBtn"),
        cancelSelectionBtn: document.getElementById("amCancelSelectionBtn")
    };

    function l(e) {
        var t;
        return 0 === e ? "0 B" : (t = Math.floor(Math.log(e) / Math.log(1024)), Math.round(e / Math.pow(1024, t) * 100) / 100 + " " + ["B", "KB", "MB", "GB"][t])
    }

    function d(e) {
        return {
            image: '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>️',
            document: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>',
            video: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"></rect><line x1="7" y1="2" x2="7" y2="22"></line><line x1="17" y1="2" x2="17" y2="22"></line><line x1="2" y1="12" x2="22" y2="12"></line><line x1="2" y1="7" x2="7" y2="7"></line><line x1="2" y1="17" x2="7" y2="17"></line><line x1="17" y1="17" x2="22" y2="17"></line><line x1="17" y1="7" x2="22" y2="7"></line></svg>',
            audio: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18V5l12-2v13"></path><circle cx="6" cy="18" r="3"></circle><circle cx="18" cy="16" r="3"></circle></svg>',
            archive: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>'
        } [e] || '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"></path></svg>'
    }

    function c() {
        if (0 === e.length) return o.tableBody.innerHTML = '\n        <tr>\n          <td colspan="9" style="text-align: center; padding: 40px;">\n            <div class="am-empty-state">\n              <div class="am-empty-icon"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg></div>\n              <p>暂无附件</p>\n</div>\n          </td>\n        </tr>\n      ';
        o.tableBody.innerHTML = e.map(e => {
            var t = i.has(e.id),
                n = e.file_path;
            return `\n        <tr class="${t?"selected":""}" data-id="${e.id}">\n          <td>\n            <input type="checkbox" class="am-checkbox" \n                   data-id="${e.id}" \n                   ${t?"checked":""}>\n          </td>\n          <td>\n            ${"image"===e.file_type?`<img src="${n}" alt="${e.file_name}" \n                     style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px; cursor: pointer;"\n                     onclick="window.open('${n}', '_blank')">`:`<div style="width: 50px; height: 50px; display: flex; align-items: center; justify-content: center; background: #f5f5f5; border-radius: 4px;">\n                ${d(e.file_type)}\n               </div>`}\n          </td>\n          <td>\n            <div style="font-weight: 500;">${e.file_name}</div>\n            <div style="font-size: 0.85em; color: #888;">${e.stored_name}</div>\n          </td>\n          <td>${d(e.file_type)} ${e.file_type}</td>\n          <td>${l(e.file_size)}</td>\n          <td>${t=e.visibility,{public:'<span class="status published">公开</span>',private:'<span class="status draft">私密</span>',protected:'<span class="status pending">受保护</span>'}[t]||t}</td>\n          <td>${e.passage_id?`<a href="/passage?id=${e.passage_id}" target="_blank">#${e.passage_id}</a>`:"-"}</td>\n          <td>${n=e.uploaded_at,new Date(n).toLocaleString("zh-CN",{year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit"})}</td>\n          <td>\n            <div class="action-buttons">\n              <button class="btn btn-sm btn-view" onclick="viewAttachment(${e.id})" title="查看">\n                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>️\n              </button>\n              <button class="btn btn-sm btn-edit" onclick="editAttachment(${e.id})" title="编辑权限">\n                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>\n              </button>\n              <button class="btn btn-sm btn-delete" onclick="deleteAttachment(${e.id})" title="删除">\n                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>️\n              </button>\n            </div>\n          </td>\n        </tr>\n      `
        }).join(""), document.querySelectorAll(".am-checkbox").forEach(e => {
            e.addEventListener("change", s)
        });
        var t = document.getElementById("amEmptyUploadBtn");
        t && t.addEventListener("click", r)
    }

    function s(e) {
        var t = parseInt(e.target.dataset.id);
        e.target.checked ? i.add(t) : (i.delete(t), o.selectAll.checked = !1), updateBatchActions()
    }

    function r() {
        document.body.insertAdjacentHTML("beforeend", '\n      <div class="modal active" id="uploadModal">\n        <div class="modal-content">\n          <div class="modal-header">\n            <h3>上传附件</h3>\n            <button class="modal-close" onclick="closeUploadModal()">×</button>\n          </div>\n          <div class="modal-body">\n            <div class="upload-area" id="uploadArea">\n              <div class="upload-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg></div>\n              <div class="upload-text">\n                <h4>拖拽文件到这里或点击上传</h4>\n                <p>支持图片、文档、视频、音频、压缩包</p>\n              </div>\n              <input type="file" id="fileInput" multiple style="display: none;">\n            </div>\n            <div class="upload-preview" id="uploadPreview"></div>\n            <div class="form-group" style="margin-top: 20px;">\n              <label for="uploadPassageId">关联文章（可选）</label>\n              <select id="uploadPassageId" class="form-control">\n                <option value="">不关联</option>\n              </select>\n            </div>\n          </div>\n          <div class="btn-group" style="padding: 0 30px 30px;">\n            <button class="btn-secondary" onclick="closeUploadModal()">取消</button>\n            <button class="btn-primary" id="confirmUploadBtn" disabled>开始上传</button>\n          </div>\n        </div>\n      </div>\n    '); {
            document.getElementById("uploadModal");
            const n = document.getElementById("uploadArea"),
                a = document.getElementById("fileInput"),
                i = document.getElementById("uploadPreview"),
                o = document.getElementById("confirmUploadBtn"),
                l = document.getElementById("uploadPassageId");
            let c = [];

            function e(e) {
                c = Array.from(e), t(), o.disabled = 0 === c.length
            }

            function t() {
                i.innerHTML = c.map((e, t) => {
                    return `\n        <div class="upload-item">\n          ${e.type.startsWith("image/")?`<img src="${URL.createObjectURL(e)}" alt="${e.name}">`:`<div style="width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; background: #f5f5f5;">\n              ${d((n=e.type,n.startsWith("image/")?"image":n.startsWith("video/")?"video":n.startsWith("audio/")?"audio":n.includes("pdf")||n.includes("document")||n.includes("word")||n.includes("excel")||n.includes("powerpoint")||!(n.includes("zip")||n.includes("tar")||n.includes("rar")||n.includes("7z"))?"document":"archive"))}\n             </div>`}\n          <button class="upload-remove" onclick="removeUploadFile(${t})">×</button>\n          <div style="position: absolute; bottom: 0; left: 0; right: 0; background: rgba(0,0,0,0.7); color: white; font-size: 0.75em; padding: 4px; text-align: center; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">\n            ${e.name}\n          </div>\n        </div>\n      `;
                    var n
                }).join("")
            }(async function(e) {
                try {
                    var t = await (await fetch("/api/admin/passages?limit=100")).json();
                    t.success && t.data && t.data.forEach(t => {
                        var n = document.createElement("option");
                        n.value = t.id, n.textContent = t.title, e.appendChild(n)
                    })
                } catch (e) {
                    console.error("加载文章列表失败:", e)
                }
            })(l), n.addEventListener("click", () => a.click()), a.addEventListener("change", t => {
                e(t.target.files)
            }), n.addEventListener("dragover", e => {
                e.preventDefault(), n.classList.add("dragover")
            }), n.addEventListener("dragleave", () => {
                n.classList.remove("dragover")
            }), n.addEventListener("drop", t => {
                t.preventDefault(), n.classList.remove("dragover"), e(t.dataTransfer.files)
            }), o.addEventListener("click", async () => {
                if (0 !== c.length) {
                    o.disabled = !0, o.textContent = "上传中...";
                    var e = l.value;
                    for (const n of c) {
                        var t = new FormData;
                        t.append("file", n), e && t.append("passage_id", e);
                        try {
                            const e = await fetch("/api/admin/attachments", {
                                    method: "POST",
                                    body: t
                                }),
                                a = await e.json();
                            a.success || h(`上传 ${n.name} 失败: ` + a.message, "error")
                        } catch (e) {
                            console.error("上传失败:", e), h(`上传 ${n.name} 失败`, "error")
                        }
                    }
                    h("上传完成", "success"), closeUploadModal(), loadAttachments()
                }
            }), window.removeUploadFile = function(e) {
                c.splice(e, 1), t(), o.disabled = 0 === c.length
            }
        }
    }
    async function m() {
        var e;
        0 !== i.size && (window.currentAction = "batch-delete-attachment", window.currentItemId = Array.from(i).join(","), e = `确定要删除选中的 ${i.size} 个附件吗？此操作不可恢复。`, document.getElementById("confirmMessage").textContent = e, openModal("confirmModal"))
    }
    async function u(e) {
        if (0 !== i.size) {
            let t = 0,
                n = 0;
            for (const a of i) try {
                (await (await fetch("/api/admin/attachments/" + a, {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        visibility: e
                    })
                })).json()).success ? t++ : n++
            } catch (e) {
                console.error("设置失败:", e), n++
            }
            0 < t && h(`成功设置 ${t} 个附件`, "success"), 0 < n && h(n + " 个附件设置失败", "error"), loadAttachments()
        }
    }

    function p() {
        i.clear(), o.selectAll.checked = !1, updateBatchActions(), c()
    }

    function h(e, t = "info") {
        const n = document.getElementById("toastContainer"),
            a = document.createElement("div");
        a.className = "toast " + t, a.innerHTML = `\n      <span class="toast-icon">${"success"===t?"✓":"error"===t?"✗":"ℹ"}</span>\n      <span class="toast-message">${e}</span>\n      <button class="toast-close" onclick="this.parentElement.remove()">×</button>\n    `, n.appendChild(a), setTimeout(() => {
            a.remove()
        }, 3e3)
    }

    function g() {
        var e;
        (e = document.getElementById("adminShortcutsHelpBtn")) && window.adminKeyboardManager && e.addEventListener("click", () => {
            window.adminKeyboardManager.showAdminShortcutHelp()
        }), o.uploadBtn && o.uploadBtn.addEventListener("click", r), o.refreshBtn && o.refreshBtn.addEventListener("click", loadAttachments), o.fileTypeFilter && o.fileTypeFilter.addEventListener("change", () => {
            t = 1, loadAttachments()
        }), o.visibilityFilter && o.visibilityFilter.addEventListener("change", () => {
            t = 1, loadAttachments()
        }), o.passageFilter && o.passageFilter.addEventListener("change", () => {
            t = 1, loadAttachments()
        }), o.searchInput && o.searchInput.addEventListener("input", function() {
            let e;
            return function() {
                clearTimeout(e), e = setTimeout(() => {
                    clearTimeout(e), t = 1, loadAttachments()
                }, 500)
            }
        }()), o.selectAll && o.selectAll.addEventListener("change", e => {
            const t = e.target.checked;
            document.querySelectorAll(".am-checkbox").forEach(e => {
                e.checked = t, e = parseInt(e.dataset.id), t ? i.add(e) : i.delete(e)
            }), updateBatchActions(), c()
        }), o.prevPageBtn && o.prevPageBtn.addEventListener("click", () => {
            1 < t && (t--, loadAttachments())
        }), o.nextPageBtn && o.nextPageBtn.addEventListener("click", () => {
            var e = Math.ceil(a / n);
            t < e && (t++, loadAttachments())
        }), o.batchDeleteBtn && o.batchDeleteBtn.addEventListener("click", m), o.batchSetPublicBtn && o.batchSetPublicBtn.addEventListener("click", () => u("public")), o.batchSetPrivateBtn && o.batchSetPrivateBtn.addEventListener("click", () => u("private")), o.cancelSelectionBtn && o.cancelSelectionBtn.addEventListener("click", p), loadAttachments(), fetch("/api/settings/appearance").then(e => e.json()).then(e => {
            function t() {
                var t = window.innerWidth <= 768 && e.mobile_background_image ? e.mobile_background_image : e.background_image;
                t && (document.body.style.backgroundImage = `url('${t}')`, document.body.style.backgroundSize = e.background_size || "cover", document.body.style.backgroundPosition = e.background_position || "center", document.body.style.backgroundRepeat = e.background_repeat || "no-repeat", document.body.style.backgroundAttachment = e.background_attachment || "fixed")
            }
            localStorage.setItem("appearanceSettings", JSON.stringify(e)), e.dark_mode_enabled && document.documentElement.classList.add("dark-mode"), (e.navbar_glass_color || e.card_glass_color || e.footer_glass_color || e.navbar_text_color) && (document.documentElement.style.setProperty("--navbar-glass-color", e.navbar_glass_color || "rgba(255, 255, 255, 0.85)"), document.documentElement.style.setProperty("--navbar-text-color", e.navbar_text_color || "rgba(255, 255, 255, 0.9)"), document.documentElement.style.setProperty("--card-glass-color", e.card_glass_color || "rgba(255, 255, 255, 0.75)"), document.documentElement.style.setProperty("--footer-glass-color", e.footer_glass_color || "rgba(255, 255, 255, 0.9)")), t(), window.addEventListener("resize", t)
        }).catch(e => {
            console.error("加载外观设置失败:", e)
        })
    }
    window.loadAttachments = async function() {
        try {
            const s = new URLSearchParams({
                    limit: n,
                    offset: (t - 1) * n
                }),
                r = o.fileTypeFilter.value,
                m = o.visibilityFilter.value,
                u = o.passageFilter.value,
                p = o.searchInput.value.trim();
            r && s.append("file_type", r), m && s.append("visibility", m), u && s.append("passage_id", u);
            var i = await (await fetch("/api/admin/attachments?" + s.toString())).json();
            if (i.success) {
                e = i.data || [], a = i.total || 0, p && (e = e.filter(e => e.file_name.toLowerCase().includes(p.toLowerCase())), a = e.length), c(); {
                    o.totalCount.textContent = a;
                    let t = 0,
                        n = 0,
                        i = 0;
                    e.forEach(e => {
                        t += e.file_size, "image" === e.file_type && n++, "document" === e.file_type && i++
                    }), o.totalSize.textContent = l(t), o.imageCount.textContent = n, o.documentCount.textContent = i
                }
                var d = Math.ceil(a / n);
                if (d <= 1) o.paginationContainer.style.display = "none";
                else {
                    o.paginationContainer.style.display = "flex", o.paginationInfo.textContent = `显示 ${(t-1)*n+1}-${Math.min(t*n,a)} 条，共 ${a} 条`, o.prevPageBtn.disabled = 1 === t, o.nextPageBtn.disabled = t === d;
                    let e = "",
                        i = Math.max(1, t - Math.floor(2.5)),
                        l = Math.min(d, i + 5 - 1);
                    for (let n = l - i < 4 ? Math.max(1, l - 5 + 1) : i; n <= l; n++) e += `<button class="pagination-page ${n===t?"active":""}" \n                       data-page="${n}">${n}</button>`;
                    o.paginationPages.innerHTML = e, document.querySelectorAll("#amPaginationPages .pagination-page").forEach(e => {
                        e.addEventListener("click", () => {
                            t = parseInt(e.dataset.page), loadAttachments()
                        })
                    })
                }
            } else h("加载附件列表失败: " + i.message, "error")
        } catch (i) {
            console.error("加载附件列表失败:", i), h("加载附件列表失败，请检查网络连接", "error")
        }
    }, window.updateBatchActions = function() {
        var e = i.size;
        o.selectedCount.textContent = e, o.batchActions.style.display = 0 < e ? "flex" : "none"
    }, window.closeUploadModal = function() {
        var e = document.getElementById("uploadModal");
        e && e.remove()
    }, window.viewAttachment = function(t) {
        var n = e.find(e => e.id === t);
        n && window.open(n.file_path, "_blank")
    }, window.editAttachment = async function(e) {
        const t = document.getElementById("editModal");
        t && t.remove();
        try {
            const t = await fetch("/api/admin/attachments/" + e),
                a = await t.json();
            if (a.success && a.data) {
                const t = Array.isArray(a.data) ? a.data[0] : a.data;
                var n = `\n          <div class="modal active" id="editModal">\n            <div class="modal-content">\n              <div class="modal-header">\n                <h3>编辑附件权限</h3>\n                <button class="modal-close" onclick="closeEditModal()">×</button>\n              </div>\n              <div class="modal-body">\n                <div class="form-group">\n                  <label>文件名</label>\n                  <input type="text" class="form-control" value="${t.file_name}" disabled>\n                </div>\n                <div class="form-group">\n                  <label for="editVisibility">可见性</label>\n                  <select id="editVisibility" class="form-control">\n                    <option value="public" ${"public"===(t.visibility||"public")?"selected":""}>公开</option>\n                    <option value="private" ${"private"===(t.visibility||"public")?"selected":""}>私密</option>\n                    <option value="protected" ${"protected"===(t.visibility||"public")?"selected":""}>受保护</option>\n                  </select>\n                </div>\n                <div class="form-group">\n                  <label for="editShowInPassage">\n                    <input type="checkbox" id="editShowInPassage" ${t.show_in_passage?"checked":""}>\n                    在文章中显示\n                  </label>\n                </div>\n              </div>\n              <div class="btn-group" style="padding: 0 30px 30px;">\n                <button class="btn-secondary" onclick="closeEditModal()">取消</button>\n                <button class="btn-primary" onclick="saveAttachmentSettings(${e})">保存</button>\n              </div>\n            </div>\n          </div>\n        `;
                document.body.insertAdjacentHTML("beforeend", n)
            } else h("获取附件信息失败: " + (a.message || "未知错误"), "error")
        } catch (e) {
            console.error("获取附件信息失败:", e), h("获取附件信息失败", "error")
        }
    }, window.saveAttachmentSettings = async function(e) {
        var t = document.getElementById("editVisibility").value,
            n = document.getElementById("editShowInPassage").checked;
        try {
            var a = await (await fetch("/api/admin/attachments/" + e, {
                method: "PATCH",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    visibility: t,
                    show_in_passage: n
                })
            })).json();
            a.success ? (h("保存成功", "success"), closeEditModal(), await loadAttachments()) : h("保存失败: " + a.message, "error")
        } catch (e) {
            h("保存失败", "error")
        }
    }, window.closeEditModal = function() {
        const e = document.getElementById("editModal");
        e && (e.classList.add("closing"), setTimeout(() => {
            e.remove()
        }, 300))
    }, window.deleteAttachment = async function(e) {
        window.currentAction = "delete-attachment", e = `确定要删除附件 #${window.currentItemId=e} 吗？此操作不可撤销。`, document.getElementById("confirmMessage").textContent = e, openModal("confirmModal")
    }, "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", g) : g()
}();
