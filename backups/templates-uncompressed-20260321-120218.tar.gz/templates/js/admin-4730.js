function showToast(e, t = "success") {
    var n = document.getElementById("toastContainer");
    if (n) {
        const a = document.createElement("div");
        a.className = "toast " + t;
        let o = "";
        switch (t) {
            case "success":
            default:
                o = "⭕";
                break;
            case "error":
                o = "❌";
                break;
            case "warning":
                o = "⚠️"
        }
        a.innerHTML = `\n    <div class="toast-icon">${o}</div>\n    <div class="toast-message">${e}</div>\n    <button class="toast-close" onclick="this.parentElement.remove()">×</button>\n  `, n.appendChild(a), setTimeout(() => {
            a.parentElement && a.remove()
        }, 3e3)
    } else console.error("Toast container not found")
}
async function fetchCategories() {
    try {
        var e = localStorage.getItem("auth_token"),
            t = {
                "Content-Type": "application/json"
            },
            n = (e && (t.Authorization = "Bearer " + e), await (await fetch("/api/admin/categories", {
                headers: t
            })).json());
        return n.success && n.data ? n.data : (console.error("获取分类列表失败:", n.message), [])
    } catch (e) {
        return console.error("获取分类列表失败:", e), []
    }
}
async function fetchTags(e = null) {
    try {
        var t = localStorage.getItem("auth_token"),
            n = {
                "Content-Type": "application/json"
            };
        t && (n.Authorization = "Bearer " + t);
        let o = "/api/admin/tags";
        null !== e && "" !== e && (o += "?category_id=" + e);
        var a = await (await fetch(o, {
            headers: n
        })).json();
        return a.success && a.data ? a.data : (console.error("获取标签列表失败:", a.message), [])
    } catch (e) {
        return console.error("获取标签列表失败:", e), []
    }
}

function updateCategoriesTable(e) {
    const t = document.querySelector("#categories tbody");
    t && (t.innerHTML = "", 0 !== e.length ? (e.forEach(e => {
        var n = document.createElement("tr");
        n.innerHTML = `\n      <td>\n        <input type="checkbox" class="category-checkbox" data-id="${e.id}">\n      </td>\n      <td>${e.sort_order}</td>\n      <td>${e.icon||""}</td>\n      <td>${e.name}</td>\n      <td>${e.description||"-"}</td>\n      <td><span style="color: ${e.is_enabled?"#00b894":"#e74c3c"};">${e.is_enabled?"启用":"禁用"}</span></td>\n      <td class="action-buttons">\n        <button class="btn btn-sm btn-edit" data-action="edit-category" data-id="${e.id}">编辑</button>\n        <button class="btn btn-sm btn-delete" data-action="delete-category" data-id="${e.id}">删除</button>\n      </td>\n    `, t.appendChild(n)
    }), bindActionButtons(), bindCategoryCheckboxes()) : t.innerHTML = '\n      <tr>\n        <td colspan="7" style="text-align: center; padding: 40px; color: #999;">\n          <div style="font-size: 48px; margin-bottom: 10px;">📭</div>\n          <div>暂无分类</div>\n        </td>\n      </tr>\n    ')
}

function updateTagsTable(e) {
    const t = document.querySelector("#tags tbody");
    t && (t.innerHTML = "", 0 !== e.length ? (e.forEach(e => {
        var n = document.createElement("tr");
        n.innerHTML = `\n      <td>\n        <input type="checkbox" class="tag-checkbox" data-id="${e.id}">\n      </td>\n      <td>${e.sort_order}</td>\n      <td><span style="display: inline-block; width: 20px; height: 20px; background-color: ${e.color}; border-radius: 4px;"></span></td>\n      <td>${e.name}</td>\n      <td>${e.description||"-"}</td>\n      <td>${0===e.category_id?"无分类":e.category_id}</td>\n      <td><span style="color: ${e.is_enabled?"#00b894":"#e74c3c"};">${e.is_enabled?"启用":"禁用"}</span></td>\n      <td class="action-buttons">\n        <button class="btn btn-sm btn-edit" data-action="edit-tag" data-id="${e.id}">编辑</button>\n        <button class="btn btn-sm btn-delete" data-action="delete-tag" data-id="${e.id}">删除</button>\n      </td>\n    `, t.appendChild(n)
    }), bindActionButtons(), bindTagCheckboxes()) : t.innerHTML = '\n      <tr>\n        <td colspan="8" style="text-align: center; padding: 40px; color: #999;">\n          <div style="font-size: 48px; margin-bottom: 10px;">📭</div>\n          <div>暂无标签</div>\n        </td>\n      </tr>\n    ')
}
async function loadCategoriesAndTags() {
    var e = await fetchCategories();
    updateCategoriesTable(e);
    const t = document.getElementById("tagCategoryFilter"),
        n = (t && (t.innerHTML = '<option value="">全部标签</option>', e.forEach(e => {
            var n = document.createElement("option");
            n.value = e.id, n.textContent = e.name, t.appendChild(n)
        })), document.getElementById("tagCategory"));
    n && (n.innerHTML = '<option value="0">无分类</option>', e.forEach(e => {
        var t = document.createElement("option");
        t.value = e.id, t.textContent = e.name, n.appendChild(t)
    })), updateTagsTable(await fetchTags())
}
async function populateCategorySelect(e, t = "") {
    const n = document.getElementById(e);
    var a;
    n && (e = await fetchCategories(), n.innerHTML = "", (a = document.createElement("option")).value = "", a.textContent = "未分类", "" !== t && "未分类" !== t || (a.selected = !0), n.appendChild(a), 0 < e.length) && e.forEach(e => {
        var a = document.createElement("option");
        a.value = e.name, a.textContent = e.name, e.icon && (a.textContent = e.icon + " " + e.name), e.name === t && (a.selected = !0), n.appendChild(a)
    })
}
async function populateTagSelector(e = []) {
    const t = document.getElementById("editTagSelector");
    var n;
    t && (n = await fetchTags(), t.innerHTML = "", 0 === n.length ? t.innerHTML = '<div style="color: #999; font-size: 0.9em;">暂无标签</div>' : (n.forEach(n => {
        var a;
        n.is_enabled && ((a = document.createElement("div")).className = "tag-option", a.dataset.tagId = n.id, a.dataset.tagName = n.name, a.innerHTML = `\n      <span style="display: inline-block; width: 12px; height: 12px; background-color: ${n.color}; border-radius: 2px; margin-right: 6px;"></span>\n      ${n.name}\n    `, e.includes(n.name) && a.classList.add("selected"), a.addEventListener("click", function() {
            this.classList.toggle("selected"), updateSelectedTags()
        }), t.appendChild(a))
    }), (n = document.getElementById("editTags")) && (n.value = JSON.stringify(e))))
}

function updateSelectedTags() {
    const e = [];
    document.querySelectorAll("#editTagSelector .tag-option.selected").forEach(t => {
        e.push(t.dataset.tagName)
    });
    var t = document.getElementById("editTags");
    t && (t.value = JSON.stringify(e))
}
async function populateTagSelectorForNewArticle() {
    const e = document.getElementById("articleTagSelector");
    var t;
    e && (t = await fetchTags(), e.innerHTML = "", 0 !== t.length ? (t.forEach(t => {
        var n;
        t.is_enabled && ((n = document.createElement("div")).className = "tag-option", n.dataset.tagId = t.id, n.dataset.tagName = t.name, n.innerHTML = `\n      <span style="display: inline-block; width: 12px; height: 12px; background-color: ${t.color}; border-radius: 2px; margin-right: 6px;"></span>\n      ${t.name}\n    `, n.addEventListener("click", function() {
            this.classList.toggle("selected"), updateSelectedTagsForNewArticle()
        }), e.appendChild(n))
    }), updateSelectedTagsForNewArticle()) : e.innerHTML = '<div style="color: #999; font-size: 0.9em;">暂无标签</div>')
}

function updateSelectedTagsForNewArticle() {
    const e = [];
    document.querySelectorAll("#articleTagSelector .tag-option.selected").forEach(t => {
        e.push(t.dataset.tagName)
    });
    var t = document.getElementById("articleTags");
    t && (t.value = JSON.stringify(e))
}
async function populateTagSelectorForUpload() {
    const e = document.getElementById("uploadTagSelector");
    var t;
    e && (t = await fetchTags(), e.innerHTML = "", 0 !== t.length ? t.forEach(t => {
        var n;
        t.is_enabled && ((n = document.createElement("div")).className = "tag-option", n.dataset.tagId = t.id, n.dataset.tagName = t.name, n.innerHTML = `\n      <span style="display: inline-block; width: 12px; height: 12px; background-color: ${t.color}; border-radius: 2px; margin-right: 6px;"></span>\n      ${t.name}\n    `, n.addEventListener("click", function() {
            this.classList.toggle("selected")
        }), e.appendChild(n))
    }) : e.innerHTML = '<div style="color: #999; font-size: 0.9em;">暂无标签</div>')
}
async function populateCategorySelectorForUpload() {
    const e = document.getElementById("uploadCategorySelector");
    var t;
    e && (t = await fetchCategories(), e.innerHTML = "", 0 !== t.length ? t.forEach(t => {
        var n;
        t.is_enabled && ((n = document.createElement("div")).className = "category-option", n.dataset.categoryId = t.id, n.dataset.categoryName = t.name, n.innerHTML = `\n      <span style="display: inline-block; width: 12px; height: 12px; background-color: #007bff; border-radius: 2px; margin-right: 6px;"></span>\n      ${t.name}\n    `, n.addEventListener("click", function() {
            this.classList.contains("selected") ? this.classList.remove("selected") : (e.querySelectorAll(".category-option").forEach(e => {
                e.classList.remove("selected")
            }), this.classList.add("selected"))
        }), e.appendChild(n))
    }) : e.innerHTML = '<div style="color: #999; font-size: 0.9em;">暂无分类</div>')
}
async function populateCategorySelectorForNewArticle() {
    const e = document.getElementById("articleCategory");
    var t, n;
    e && (t = await fetchCategories(), e.innerHTML = "", 0 === t.length ? ((n = document.createElement("option")).value = "", n.textContent = "暂无分类", e.appendChild(n)) : t.forEach(t => {
        var n = document.createElement("option");
        n.value = t.name, n.textContent = t.name, e.appendChild(n)
    }))
}
async function fetchAdminData(e = 1, t = 10, n = 1, a = 10, o = 1, d = 10) {
    try {
        var c = localStorage.getItem("auth_token"),
            s = {
                "Content-Type": "application/json"
            },
            r = (c && (s.Authorization = "Bearer " + c), await (await fetch(`/api/admin/passages?page=${e}&limit=` + t, {
                headers: s
            })).json()),
            i = (r.success && r.data && 0 < r.data.length ? (updateArticlesTable(r.data), updateStatCard("totalArticles", r.pagination?.total || r.data.length), updatePagination(r.pagination)) : (showEmptyState("articlesTableBody", "暂无文章"), updateStatCard("totalArticles", 0), hidePagination()), await (await fetch(`/api/admin/users?page=${n}&limit=` + a, {
                headers: s
            })).json()),
            l = (i.success && i.data && 0 < i.data.length ? (updateUsersTable(i.data), updateStatCard("totalUsers", i.pagination?.total || i.data.length), updateUserPagination(i.pagination)) : (showEmptyState("usersTableBody", "暂无用户", 7), updateStatCard("totalUsers", 0), hideUserPagination()), await (await fetch(`/api/admin/comments?page=${o}&limit=` + d, {
                headers: s
            })).json()),
            m = (l.success && l.data && 0 < l.data.length ? (updateCommentsTable(l.data), updateCommentsPagination(l.pagination)) : (showEmptyState("commentsTableBody", "暂无评论", 6), hideCommentsPagination()), await (await fetch("/api/admin/stats", {
                headers: s
            })).json());
        if (m.success && m.data) {
            updateStatCard("todayVisits", m.data.today_visits || 0);
            const e = document.querySelector("#todayVisits").closest(".stat-card").querySelector(".stat-change");
            if (e && void 0 !== m.data.yesterday_visits) {
                m.data.yesterday_visits;
                const t = m.data.visits_change_percent || 0,
                    n = m.data.visits_trend || "stable";
                "up" === n ? (e.className = "stat-change positive", e.textContent = `较昨日 +${t.toFixed(1)}%`) : "down" === n ? (e.className = "stat-change negative", e.textContent = `较昨日 ${t.toFixed(1)}%`) : (e.className = "stat-change neutral", e.textContent = "较昨日持平")
            }
        } else console.error("获取统计数据失败:", m)
    } catch (e) {
        console.error("获取管理数据失败:", e)
    }
}

function showEmptyState(e, t, n = 6) {
    var a;
    (e = document.querySelector("#" + e)) && (a = localStorage.getItem("auth_token"), e.innerHTML = `\n    <tr>\n      <td colspan="${n}" style="text-align: center; padding: 40px; color: #999;">\n        <div style="font-size: 48px; margin-bottom: 10px;">📭</div>\n        <div>${a?t:"请先登录以查看数据"}</div>\n        ${a?"":'<div style="margin-top: 10px; font-size: 0.9em;"><a href="#loginModal" onclick="document.getElementById(\'loginBtn\').click(); return false;" style="color: #007bff; text-decoration: none;">点击登录</a></div>'}\n      </td>\n    </tr>\n  `)
}
let currentPage = 1,
    currentLimit = 100,
    totalPages = 1;

function updatePagination(e) {
    var t, n, a, o;
    e ? (t = parseInt(e.page) || 1, n = parseInt(e.limit) || 100, e = parseInt(e.total) || 0, currentPage = t, currentLimit = n, totalPages = Math.ceil(e / n), (o = document.getElementById("paginationContainer")) && (o.style.display = "flex"), o = (t - 1) * n + 1, n = Math.min(t * n, e), (a = document.getElementById("paginationInfo")) && (a.textContent = `显示 ${o}-${n} 条，共 ${e} 条`), a = document.getElementById("prevPageBtn"), o = document.getElementById("nextPageBtn"), a && (a.disabled = t <= 1), o && (o.disabled = t >= totalPages), generatePageButtons(t, totalPages)) : hidePagination()
}

function hidePagination() {
    var e = document.getElementById("paginationContainer");
    e && (e.style.display = "none")
}

function generatePageButtons(e, t) {
    var n = document.getElementById("paginationPages");
    if (n) {
        n.innerHTML = "";
        let a = Math.max(1, e - 2),
            o = Math.min(t, e + 2);
        o - a < 4 && (1 === a ? o = Math.min(t, 5) : o === t && (a = Math.max(1, t - 4))), 1 < a && (addPageButton(1, n), 2 < a) && addEllipsis(n);
        for (let t = a; t <= o; t++) addPageButton(t, n, t === e);
        o < t && (o < t - 1 && addEllipsis(n), addPageButton(t, n))
    }
}

function addPageButton(e, t, n = !1) {
    var a = document.createElement("button");
    a.className = "pagination-page " + (n ? "active" : ""), a.textContent = e, a.addEventListener("click", () => {
        e !== currentPage && fetchAdminData(e, currentLimit)
    }), t.appendChild(a)
}

function addEllipsis(e) {
    var t = document.createElement("span");
    t.className = "pagination-page ellipsis", t.textContent = "...", e.appendChild(t)
}

function goToPrevPage() {
    1 < currentPage && fetchAdminData(currentPage - 1, currentLimit)
}

function goToNextPage() {
    currentPage < totalPages && fetchAdminData(currentPage + 1, currentLimit)
}

function getUsernameFromToken() {
    var e = localStorage.getItem("auth_token");
    if (!e) return "管理员";
    try {
        var t, n, a = e.split(".");
        return 3 === a.length && (t = a[1].replace(/-/g, "+").replace(/_/g, "/"), n = atob(t), JSON.parse(n).username) || "管理员"
    } catch (e) {
        return console.error("解析token失败:", e), "管理员"
    }
}
async function updateWelcomeMessage() {
    const e = getUsernameFromToken(),
        t = document.querySelector(".welcome-text h2");
    t && (t.textContent = "欢迎回来，" + e);
    let n = "/img/avatar.webp";
    try {
        const e = localStorage.getItem("auth_token"),
            t = {
                "Content-Type": "application/json"
            },
            a = (e && (t.Authorization = "Bearer " + e), await fetch("/api/settings/template", {
                method: "GET",
                headers: t
            }));
        if (a.ok) {
            const e = await a.json();
            e.global_avatar && (n = e.global_avatar)
        }
    } catch (e) {
        console.error("获取全局头像设置失败:", e)
    }
    const a = document.querySelector(".admin-avatar");
    a && (a.innerHTML = `<img src="${n}" alt="${e}" class="avatar-image">`)
}
document.addEventListener("DOMContentLoaded", function() {
    updateWelcomeMessage();
    var e = document.getElementById("prevPageBtn"),
        t = document.getElementById("nextPageBtn"),
        n = document.getElementById("refreshArticlesBtn");
    e && e.addEventListener("click", goToPrevPage), t && t.addEventListener("click", goToNextPage), n && n.addEventListener("click", () => {
        fetchAdminData(currentPage, currentLimit)
    }), e = document.getElementById("prevUserPageBtn"), t = document.getElementById("nextUserPageBtn"), e && e.addEventListener("click", goToPrevUserPage), t && t.addEventListener("click", goToNextUserPage), n = document.getElementById("prevCommentsPageBtn"), e = document.getElementById("nextCommentsPageBtn"), t = document.getElementById("refreshCommentsBtn"), n && n.addEventListener("click", goToPrevCommentsPage), e && e.addEventListener("click", goToNextCommentsPage), t && t.addEventListener("click", () => {
        fetchAdminData(currentPage, currentLimit, currentUserPage, currentUserLimit, currentCommentsPage, currentCommentsLimit)
    }), (n = document.getElementById("batchDeleteCommentsBtn")) && n.addEventListener("click", batchDeleteComments), e = document.getElementById("addCategoryBtn"), t = document.getElementById("refreshCategoriesBtn"), e && e.addEventListener("click", () => {
        document.getElementById("categoryModalTitle").textContent = "添加分类", document.getElementById("categoryForm").reset(), delete document.getElementById("categoryForm").dataset.categoryId, openModal("categoryModal")
    }), t && t.addEventListener("click", loadCategoriesAndTags), (n = document.getElementById("batchDeleteCategoriesBtn")) && n.addEventListener("click", batchDeleteCategories), e = document.getElementById("addTagBtn"), t = document.getElementById("refreshTagsBtn"), n = document.getElementById("tagCategoryFilter"), e && e.addEventListener("click", async () => {
        await loadCategoriesAndTags(), document.getElementById("tagModalTitle").textContent = "添加标签", document.getElementById("tagForm").reset(), delete document.getElementById("tagForm").dataset.tagId, openModal("tagModal")
    }), t && t.addEventListener("click", loadCategoriesAndTags), (e = document.getElementById("batchDeleteTagsBtn")) && e.addEventListener("click", batchDeleteTags), n && n.addEventListener("change", async function() {
        updateTagsTable(await fetchTags(this.value))
    })
});
let currentUserPage = 1,
    currentUserLimit = 10,
    totalUserPages = 1;

function updateUserPagination(e) {
    var t, n, a, o;
    e ? (t = parseInt(e.page) || 1, n = parseInt(e.limit) || 100, e = parseInt(e.total) || 0, currentUserPage = t, currentUserLimit = n, totalUserPages = Math.ceil(e / n), (o = document.getElementById("userPaginationContainer")) && (o.style.display = "flex"), o = (t - 1) * n + 1, n = Math.min(t * n, e), (a = document.getElementById("userPaginationInfo")) && (a.textContent = `显示 ${o}-${n} 条，共 ${e} 条`), a = document.getElementById("prevUserPageBtn"), o = document.getElementById("nextUserPageBtn"), a && (a.disabled = t <= 1), o && (o.disabled = t >= totalUserPages), generateUserPageButtons(t, totalUserPages)) : hideUserPagination()
}

function hideUserPagination() {
    var e = document.getElementById("userPaginationContainer");
    e && (e.style.display = "none")
}

function generateUserPageButtons(e, t) {
    var n = document.getElementById("userPaginationPages");
    if (n) {
        n.innerHTML = "";
        let a = Math.max(1, e - 2),
            o = Math.min(t, e + 2);
        o - a < 4 && (1 === a ? o = Math.min(t, 5) : o === t && (a = Math.max(1, t - 4))), 1 < a && (addUserPageButton(1, n), 2 < a) && addUserEllipsis(n);
        for (let t = a; t <= o; t++) addUserPageButton(t, n, t === e);
        o < t && (o < t - 1 && addUserEllipsis(n), addUserPageButton(t, n))
    }
}

function addUserPageButton(e, t, n = !1) {
    var a = document.createElement("button");
    a.className = "pagination-page " + (n ? "active" : ""), a.textContent = e, a.addEventListener("click", () => {
        e !== currentUserPage && fetchAdminData(currentPage, currentLimit, e, currentUserLimit)
    }), t.appendChild(a)
}

function addUserEllipsis(e) {
    var t = document.createElement("span");
    t.className = "pagination-page ellipsis", t.textContent = "...", e.appendChild(t)
}

function goToPrevUserPage() {
    1 < currentUserPage && fetchAdminData(currentPage, currentLimit, currentUserPage - 1, currentUserLimit)
}

function goToNextUserPage() {
    currentUserPage < totalUserPages && fetchAdminData(currentPage, currentLimit, currentUserPage + 1, currentUserLimit)
}
let currentCommentsPage = 1,
    currentCommentsLimit = 10,
    totalCommentsPages = 1;

function updateCommentsTable(e) {
    const t = document.querySelector("#comments tbody");
    t && (t.innerHTML = "", e.forEach(e => {
        var n = document.createElement("tr"),
            a = generateAdminIdenticon(e.username || "anonymous", 24);
        n.innerHTML = `\n      <td>\n        <input type="checkbox" class="comment-checkbox" data-id="${e.id}">\n      </td>\n      <td style="max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${e.content}</td>\n      <td>${e.passage_uuid}</td>\n      <td>\n        <div style="display: flex; align-items: center; gap: 8px;">\n          <img src="${a}" alt="${e.username||"匿名用户"}" style="width: 24px; height: 24px; border-radius: 50%;"/>\n          <span>${e.username}</span>\n        </div>\n      </td>\n      <td>${e.created_at}</td>\n      <td class="action-buttons">\n        <button class="btn btn-sm btn-delete" data-action="delete-comment" data-id="${e.id}">删除</button>\n      </td>\n    `, t.appendChild(n)
    }), bindActionButtons(), bindCommentCheckboxes())
}

function generateAdminIdenticon(e, t = 24) {
    var n = simpleAdminHash(e),
        a = 65 + n % 15,
        o = 55 + n % 10,
        d = `hsl(${c=n%360}, ${a}%, ${o}%)`,
        c = `hsl(${c}, ${a}%, ${o-25}%)`;
    let s = "";
    for (let e = 0; e < 5; e++)
        for (let t = 0; t < Math.ceil(2.5); t++) n >> 5 * e + t & 1 && (s = (s += `<rect x="${t}" y="${e}" width="1" height="1" fill="${d}"/>`) + `<rect x="${4-t}" y="${e}" width="1" height="1" fill="${d}"/>`);
    return a = e ? e.charAt(0).toUpperCase() : "?", "data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(`\n    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 5 5" width="${t}" height="${t}">\n      <rect width="5" height="5" fill="#f0f0f0"/>\n      ${s}\n      <text x="2.5" y="2.85" \n            text-anchor="middle" \n            font-size="2.5" \n            font-weight="bold" \n            fill="${c}"\n            font-family="system-ui, -apple-system, sans-serif">${a}</text>\n    </svg>\n  `)))
}

function simpleAdminHash(e) {
    let t = 0;
    for (let n = 0; n < e.length; n++) t = (t << 5) - t + e.charCodeAt(n), t &= t;
    return Math.abs(t)
}

function bindCommentCheckboxes() {
    const e = document.getElementById("selectAllComments"),
        t = document.querySelectorAll(".comment-checkbox");
    e && e.addEventListener("change", function() {
        t.forEach(e => {
            e.checked = this.checked, (e = e.closest("tr")) && (this.checked ? e.classList.add("selected") : e.classList.remove("selected"))
        }), updateBatchDeleteButton()
    }), t.forEach(e => {
        e.addEventListener("change", function() {
            var e = this.closest("tr");
            e && (this.checked ? e.classList.add("selected") : e.classList.remove("selected")), updateBatchDeleteButton(), updateSelectAllCheckbox()
        })
    })
}

function updateBatchDeleteButton() {
    var e = document.querySelectorAll(".comment-checkbox:checked").length,
        t = document.getElementById("batchDeleteCommentsBtn");
    t && (0 < e ? (t.style.display = "inline-block", t.textContent = `批量删除 (${e})`) : t.style.display = "none")
}

function updateSelectAllCheckbox() {
    var e, t = document.getElementById("selectAllComments"),
        n = document.querySelectorAll(".comment-checkbox");
    t && 0 < n.length && (e = Array.from(n).every(e => e.checked), n = Array.from(n).some(e => e.checked), t.checked = e, t.indeterminate = n && !e)
}

function clearCommentSelection() {
    var e = document.getElementById("selectAllComments"),
        t = document.querySelectorAll(".comment-checkbox");
    e && (e.checked = !1, e.indeterminate = !1), t.forEach(e => {
        e.checked = !1, (e = e.closest("tr")) && e.classList.remove("selected")
    }), updateBatchDeleteButton()
}
async function batchDeleteComments() {
    var e = document.querySelectorAll(".comment-checkbox:checked");
    0 !== (e = Array.from(e).map(e => parseInt(e.dataset.id))).length ? (currentAction = "batch-delete-comments", currentItemId = e.join(","), document.getElementById("confirmMessage").textContent = `确定要删除选中的 ${e.length} 条评论吗？此操作不可恢复！`, openModal("confirmModal")) : showToast("请选择要删除的评论", "warning")
}

function bindCategoryCheckboxes() {
    const e = document.getElementById("selectAllCategories"),
        t = document.querySelectorAll(".category-checkbox");
    e && e.addEventListener("change", function() {
        t.forEach(e => {
            e.checked = this.checked, (e = e.closest("tr")) && (this.checked ? e.classList.add("selected") : e.classList.remove("selected"))
        }), updateBatchDeleteCategoriesButton()
    }), t.forEach(e => {
        e.addEventListener("change", function() {
            var e = this.closest("tr");
            e && (this.checked ? e.classList.add("selected") : e.classList.remove("selected")), updateBatchDeleteCategoriesButton(), updateSelectAllCategoriesCheckbox()
        })
    })
}

function updateBatchDeleteCategoriesButton() {
    var e = document.querySelectorAll(".category-checkbox:checked").length,
        t = document.getElementById("batchDeleteCategoriesBtn");
    t && (0 < e ? (t.style.display = "inline-block", t.textContent = `批量删除 (${e})`) : t.style.display = "none")
}

function updateSelectAllCategoriesCheckbox() {
    var e, t = document.getElementById("selectAllCategories"),
        n = document.querySelectorAll(".category-checkbox");
    t && 0 < n.length && (e = Array.from(n).every(e => e.checked), n = Array.from(n).some(e => e.checked), t.checked = e, t.indeterminate = n && !e)
}

function clearCategorySelection() {
    var e = document.getElementById("selectAllCategories"),
        t = document.querySelectorAll(".category-checkbox");
    e && (e.checked = !1, e.indeterminate = !1), t.forEach(e => {
        e.checked = !1, (e = e.closest("tr")) && e.classList.remove("selected")
    }), updateBatchDeleteCategoriesButton()
}
async function batchDeleteCategories() {
    var e = document.querySelectorAll(".category-checkbox:checked");
    0 !== (e = Array.from(e).map(e => parseInt(e.dataset.id))).length ? (currentAction = "batch-delete-categories", currentItemId = e.join(","), document.getElementById("confirmMessage").textContent = `确定要删除选中的 ${e.length} 个分类吗？此操作不可恢复！`, openModal("confirmModal")) : showToast("请选择要删除的分类", "warning")
}

function bindTagCheckboxes() {
    const e = document.getElementById("selectAllTags"),
        t = document.querySelectorAll(".tag-checkbox");
    e && e.addEventListener("change", function() {
        t.forEach(e => {
            e.checked = this.checked, (e = e.closest("tr")) && (this.checked ? e.classList.add("selected") : e.classList.remove("selected"))
        }), updateBatchDeleteTagsButton()
    }), t.forEach(e => {
        e.addEventListener("change", function() {
            var e = this.closest("tr");
            e && (this.checked ? e.classList.add("selected") : e.classList.remove("selected")), updateBatchDeleteTagsButton(), updateSelectAllTagsCheckbox()
        })
    })
}

function updateBatchDeleteTagsButton() {
    var e = document.querySelectorAll(".tag-checkbox:checked").length,
        t = document.getElementById("batchDeleteTagsBtn");
    t && (0 < e ? (t.style.display = "inline-block", t.textContent = `批量删除 (${e})`) : t.style.display = "none")
}

function updateSelectAllTagsCheckbox() {
    var e, t = document.getElementById("selectAllTags"),
        n = document.querySelectorAll(".tag-checkbox");
    t && 0 < n.length && (e = Array.from(n).every(e => e.checked), n = Array.from(n).some(e => e.checked), t.checked = e, t.indeterminate = n && !e)
}

function clearTagSelection() {
    var e = document.getElementById("selectAllTags"),
        t = document.querySelectorAll(".tag-checkbox");
    e && (e.checked = !1, e.indeterminate = !1), t.forEach(e => {
        e.checked = !1, (e = e.closest("tr")) && e.classList.remove("selected")
    }), updateBatchDeleteTagsButton()
}
async function batchDeleteTags() {
    var e = document.querySelectorAll(".tag-checkbox:checked");
    0 !== (e = Array.from(e).map(e => parseInt(e.dataset.id))).length ? (currentAction = "batch-delete-tags", currentItemId = e.join(","), document.getElementById("confirmMessage").textContent = `确定要删除选中的 ${e.length} 个标签吗？此操作不可恢复！`, openModal("confirmModal")) : showToast("请选择要删除的标签", "warning")
}

function updateCommentsPagination(e) {
    var t, n, a, o;
    e ? (t = parseInt(e.page) || 1, n = parseInt(e.limit) || 100, e = parseInt(e.total) || 0, currentCommentsPage = t, currentCommentsLimit = n, totalCommentsPages = Math.ceil(e / n), (o = document.getElementById("commentsPaginationContainer")) && (o.style.display = "flex"), o = (t - 1) * n + 1, n = Math.min(t * n, e), (a = document.getElementById("commentsPaginationInfo")) && (a.textContent = `显示 ${o}-${n} 条，共 ${e} 条`), a = document.getElementById("prevCommentsPageBtn"), o = document.getElementById("nextCommentsPageBtn"), a && (a.disabled = t <= 1), o && (o.disabled = t >= totalCommentsPages), generateCommentsPageButtons(t, totalCommentsPages)) : hideCommentsPagination()
}

function hideCommentsPagination() {
    var e = document.getElementById("commentsPaginationContainer");
    e && (e.style.display = "none")
}

function generateCommentsPageButtons(e, t) {
    var n = document.getElementById("commentsPaginationPages");
    if (n) {
        n.innerHTML = "";
        let a = Math.max(1, e - 2),
            o = Math.min(t, e + 2);
        o - a < 4 && (1 === a ? o = Math.min(t, 5) : o === t && (a = Math.max(1, t - 4))), 1 < a && (addCommentsPageButton(1, n), 2 < a) && addCommentsEllipsis(n);
        for (let t = a; t <= o; t++) addCommentsPageButton(t, n, t === e);
        o < t && (o < t - 1 && addCommentsEllipsis(n), addCommentsPageButton(t, n))
    }
}

function addCommentsPageButton(e, t, n = !1) {
    var a = document.createElement("button");
    a.className = "pagination-page " + (n ? "active" : ""), a.textContent = e, a.addEventListener("click", () => {
        e !== currentCommentsPage && fetchAdminData(currentPage, currentLimit, currentUserPage, currentUserLimit, e, currentCommentsLimit)
    }), t.appendChild(a)
}

function addCommentsEllipsis(e) {
    var t = document.createElement("span");
    t.className = "pagination-page ellipsis", t.textContent = "...", e.appendChild(t)
}

function goToPrevCommentsPage() {
    1 < currentCommentsPage && fetchAdminData(currentPage, currentLimit, currentUserPage, currentUserLimit, currentCommentsPage - 1, currentCommentsLimit)
}

function goToNextCommentsPage() {
    currentCommentsPage < totalCommentsPages && fetchAdminData(currentPage, currentLimit, currentUserPage, currentUserLimit, currentCommentsPage + 1, currentCommentsLimit)
}

function updateArticlesTable(e) {
    const t = document.querySelector("#articles tbody");
    t && (t.innerHTML = "", e.forEach(e => {
        const n = document.createElement("tr");
        n.dataset.articleId = e.id;
        let a = `<span class="status ${e.status||"published"}">${getStatusText(e.status||"published")}</span>`;
        e.is_scheduled && (a += ` <span class="status scheduled" title="定时发布">⏰ ${e.published_at?formatDate(e.published_at):"未设置"}</span>`);
        var o = "public" === (d = e.visibility || "public") ? "公开" : "私密",
            d = "public" === d ? "visibility-public" : "visibility-private";
        n.innerHTML = `\n      <td>\n        <input type="checkbox" class="article-checkbox" data-id="${e.id}">\n      </td>\n      <td>${e.title}</td>\n      <td>管理员</td>\n      <td>${formatDate(e.created_at)||"2024-01-01"}</td>\n      <td>${a}</td>\n      <td><span class="visibility ${d}">${o}</span></td>\n      <td class="action-buttons">\n        <button class="btn btn-sm btn-view" data-action="view" data-id="${e.id}">查看</button>\n        <button class="btn btn-sm btn-edit" data-action="edit" data-id="${e.id}">编辑</button>\n        <button class="btn btn-sm btn-upload" data-action="upload" data-id="${e.id}">上传附件</button>\n        <button class="btn btn-sm btn-delete" data-action="delete" data-id="${e.id}">删除</button>\n      </td>\n    `, n.addEventListener("click", e => {
            e.target.closest(".action-buttons") || e.target.classList.contains("article-checkbox") || ((e = n.querySelector(".article-checkbox")).checked = !e.checked, n.classList.toggle("selected", e.checked), updateBatchActionsBar())
        }), n.querySelector(".article-checkbox").addEventListener("change", e => {
            n.classList.toggle("selected", e.target.checked), updateBatchActionsBar()
        }), t.appendChild(n)
    }), bindActionButtons(), bindBatchActionEvents())
}

function bindBatchActionEvents() {
    var e = document.getElementById("selectAllCheckbox"),
        t = document.getElementById("batchDeleteBtn"),
        n = document.getElementById("clearSelectionBtn");
    e && e.addEventListener("change", e => {
        document.querySelectorAll(".article-checkbox").forEach(t => {
            t.checked = e.target.checked, (t = t.closest("tr")) && t.classList.toggle("selected", e.target.checked)
        }), updateBatchActionsBar()
    }), t && t.addEventListener("click", batchDeleteArticles), n && n.addEventListener("click", clearSelection)
}

function updateBatchActionsBar() {
    const e = document.querySelectorAll(".article-checkbox:checked"),
        t = document.getElementById("batchActionsBar"),
        n = document.getElementById("selectedCount"),
        a = document.getElementById("selectAllCheckbox"),
        o = e.length;
    if (0 < o ? (t.style.display = "flex", n.textContent = `已选择 ${o} 篇文章`) : t.style.display = "none", a) {
        const e = document.querySelectorAll(".article-checkbox");
        0 < e.length && o === e.length ? (a.checked = !0, a.indeterminate = !1) : 0 < o ? (a.checked = !1, a.indeterminate = !0) : (a.checked = !1, a.indeterminate = !1)
    }
}
async function batchDeleteArticles() {
    var e = document.querySelectorAll(".article-checkbox:checked");
    0 !== (e = Array.from(e).map(e => parseInt(e.dataset.id))).length ? (currentAction = "batch-delete-articles", currentItemId = e.join(","), document.getElementById("confirmMessage").textContent = `确定要删除选中的 ${e.length} 篇文章吗？此操作不可恢复！`, openModal("confirmModal")) : showToast("请选择要删除的文章", "warning")
}

function clearSelection() {
    document.querySelectorAll(".article-checkbox").forEach(e => {
        e.checked = !1, (e = e.closest("tr")) && e.classList.remove("selected")
    });
    var e = document.getElementById("selectAllCheckbox");
    e && (e.checked = !1, e.indeterminate = !1), updateBatchActionsBar()
}

function bindUserBatchActionEvents() {
    var e = document.getElementById("selectAllUsersCheckbox"),
        t = document.getElementById("batchDeleteUsersBtn"),
        n = document.getElementById("clearUserSelectionBtn");
    e && e.addEventListener("change", e => {
        document.querySelectorAll(".user-checkbox:not(:disabled)").forEach(t => {
            t.checked = e.target.checked, (t = t.closest("tr")) && t.classList.toggle("selected", e.target.checked)
        }), updateUserBatchActionsBar()
    }), t && t.addEventListener("click", batchDeleteUsers), n && n.addEventListener("click", clearUserSelection)
}

function updateUserBatchActionsBar() {
    const e = document.querySelectorAll(".user-checkbox:checked"),
        t = document.getElementById("userBatchActionsBar"),
        n = document.getElementById("userSelectedCount"),
        a = document.getElementById("selectAllUsersCheckbox"),
        o = e.length;
    if (0 < o ? (t.style.display = "flex", n.textContent = `已选择 ${o} 个用户`) : t.style.display = "none", a) {
        const e = document.querySelectorAll(".user-checkbox:not(:disabled)");
        0 < e.length && o === e.length ? (a.checked = !0, a.indeterminate = !1) : 0 < o ? (a.checked = !1, a.indeterminate = !0) : (a.checked = !1, a.indeterminate = !1)
    }
}
async function batchDeleteUsers() {
    var e = document.querySelectorAll(".user-checkbox:checked");
    0 !== (e = Array.from(e).map(e => parseInt(e.dataset.id))).length ? (currentAction = "batch-delete-users", currentItemId = e.join(","), document.getElementById("confirmMessage").textContent = `确定要删除选中的 ${e.length} 个用户吗？此操作不可恢复！`, openModal("confirmModal")) : showToast("请选择要删除的用户", "warning")
}

function clearUserSelection() {
    document.querySelectorAll(".user-checkbox").forEach(e => {
        e.checked = !1, (e = e.closest("tr")) && e.classList.remove("selected")
    });
    var e = document.getElementById("selectAllUsersCheckbox");
    e && (e.checked = !1, e.indeterminate = !1), updateUserBatchActionsBar()
}

function formatDate(e) {
    return e ? new Date(e).toLocaleString("zh-CN", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit"
    }) : ""
}

function updateUsersTable(e) {
    const t = document.querySelector("#users tbody");
    t && (t.innerHTML = "", e.forEach(e => {
        const n = document.createElement("tr");
        n.dataset.userId = e.id, n.innerHTML = `\n      <td>\n        <input type="checkbox" class="user-checkbox" data-id="${e.id}" ${"admin"===e.role?"disabled":""}>\n      </td>\n      <td>${e.username}</td>\n      <td>${e.email}</td>\n      <td>${e.created_at||"2024-01-01"}</td>\n      <td>${"admin"===e.role?"管理员":"editor"===e.role?"编辑":"普通用户"}</td>\n      <td><span style="color:${"active"===e.status?"#00b894":"restricted"===e.status?"#fdcb6e":"#e74c3c"};">${"active"===e.status?"正常":"restricted"===e.status?"受限":"禁用"}</span></td>\n      <td class="action-buttons">\n        <button class="btn btn-sm btn-view" data-action="view-user" data-id="${e.id}">详情</button>\n        <button class="btn btn-sm btn-edit" data-action="edit-user" data-id="${e.id}">编辑</button>\n        ${"admin"!==e.role?`<button class="btn btn-sm btn-delete" data-action="delete-user" data-id="${e.id}">删除</button>`:""}\n      </td>\n    `, n.addEventListener("click", e => {
            e.target.closest(".action-buttons") || e.target.classList.contains("user-checkbox") || (e = n.querySelector(".user-checkbox")).disabled || (e.checked = !e.checked, n.classList.toggle("selected", e.checked), updateUserBatchActionsBar())
        }), n.querySelector(".user-checkbox").addEventListener("change", e => {
            n.classList.toggle("selected", e.target.checked), updateUserBatchActionsBar()
        }), t.appendChild(n)
    }), bindActionButtons(), bindUserBatchActionEvents())
}

function updateStatCard(e, t) {
    (e = document.getElementById(e)) && (e.textContent = t)
}

function getAuthHeaders() {
    var e = localStorage.getItem("auth_token");
    return e ? {
        Authorization: "Bearer " + e
    } : {}
}
let viewTrendChart = null;
async function loadMostViewedArticles() {
    var e = document.getElementById("mostViewedLimit")?.value || 10,
        t = document.getElementById("mostViewedTableBody");
    if (t) {
        t.innerHTML = '<tr><td colspan="4" style="text-align: center;">加载中...</td></tr>';
        try {
            var n = await (await fetch("/api/admin/analytics?action=most-viewed&limit=" + e, {
                headers: getAuthHeaders()
            })).json();
            n.success && n.data ? 0 === n.data.length ? t.innerHTML = '<tr><td colspan="4" style="text-align: center;">暂无数据</td></tr>' : t.innerHTML = n.data.map((e, t) => `\n        <tr>\n          <td>${t+1}</td>\n          <td>${e.title}</td>\n          <td>${e.author}</td>\n          <td>${e.view_count}</td>\n        </tr>\n      `).join("") : t.innerHTML = '<tr><td colspan="4" style="text-align: center;">加载失败</td></tr>'
        } catch (e) {
            console.error("加载热门文章失败:", e), t.innerHTML = '<tr><td colspan="4" style="text-align: center;">加载失败</td></tr>'
        }
    }
}
async function loadViewSources() {
    var e = document.getElementById("viewSourcesDays")?.value || 30,
        t = document.getElementById("viewSourcesTableBody");
    if (t) {
        t.innerHTML = '<tr><td colspan="3" style="text-align: center;">加载中...</td></tr>';
        try {
            var n = await (await fetch("/api/admin/analytics?action=view-sources&days=" + e, {
                headers: getAuthHeaders()
            })).json();
            n.success && n.data ? 0 === n.data.length ? t.innerHTML = '<tr><td colspan="3" style="text-align: center;">暂无数据</td></tr>' : t.innerHTML = n.data.map((e, t) => `\n        <tr>\n          <td>${t+1}</td>\n          <td>${"unknown"===e.country?"未知":e.country}</td>\n          <td>${e.count}</td>\n        </tr>\n      `).join("") : t.innerHTML = '<tr><td colspan="3" style="text-align: center;">加载失败</td></tr>'
        } catch (e) {
            console.error("加载访问来源失败:", e), t.innerHTML = '<tr><td colspan="3" style="text-align: center;">加载失败</td></tr>'
        }
    }
}
async function loadViewByCity() {
    var e = document.getElementById("viewByCityDays")?.value || 30,
        t = document.getElementById("viewByCityTableBody");
    if (t) {
        t.innerHTML = '<tr><td colspan="4" style="text-align: center;">加载中...</td></tr>';
        try {
            var n = await (await fetch("/api/admin/analytics?action=view-by-city&days=" + e, {
                headers: getAuthHeaders()
            })).json();
            n.success && n.data ? 0 === n.data.length ? t.innerHTML = '<tr><td colspan="4" style="text-align: center;">暂无数据</td></tr>' : t.innerHTML = n.data.map((e, t) => `\n        <tr>\n          <td>${t+1}</td>\n          <td>${"unknown"===e.city?"未知":e.city}</td>\n          <td>${"unknown"===e.country?"未知":e.country}</td>\n          <td>${e.count}</td>\n        </tr>\n      `).join("") : t.innerHTML = '<tr><td colspan="4" style="text-align: center;">加载失败</td></tr>'
        } catch (e) {
            console.error("加载城市统计失败:", e), t.innerHTML = '<tr><td colspan="4" style="text-align: center;">加载失败</td></tr>'
        }
    }
}
async function loadViewByIP() {
    var e = document.getElementById("viewByIPDays")?.value || 30,
        t = document.getElementById("viewByIPTableBody");
    if (t) {
        t.innerHTML = '<tr><td colspan="8" style="text-align: center;">加载中...</td></tr>';
        try {
            var n = await (await fetch("/api/admin/analytics?action=view-by-ip&days=" + e, {
                headers: getAuthHeaders()
            })).json();
            n.success && n.data ? 0 === n.data.length ? t.innerHTML = '<tr><td colspan="8" style="text-align: center;">暂无数据</td></tr>' : t.innerHTML = n.data.map((e, t) => `\n        <tr>\n          <td>${t+1}</td>\n          <td>${e.ip}</td>\n          <td>${"unknown"===e.country?"未知":e.country||"-"}</td>\n          <td>${"unknown"===e.city?"未知":e.city||"-"}</td>\n          <td>${"unknown"===e.region?"未知":e.region||"-"}</td>\n          <td>${e.count}</td>\n          <td>${e.firstVisit}</td>\n          <td>${e.lastVisit}</td>\n        </tr>\n      `).join("") : t.innerHTML = '<tr><td colspan="8" style="text-align: center;">加载失败</td></tr>'
        } catch (e) {
            console.error("加载IP统计失败:", e), t.innerHTML = '<tr><td colspan="8" style="text-align: center;">加载失败</td></tr>'
        }
    }
}
async function loadViewTrend() {
    var e = document.getElementById("viewTrendDays")?.value || 30;
    if (document.getElementById("viewTrendChart")) try {
        var t = await (await fetch("/api/admin/analytics?action=view-trend&days=" + e, {
            headers: getAuthHeaders()
        })).json();
        t.success && t.data && drawViewTrendChart(t.data)
    } catch (e) {
        console.error("加载阅读趋势失败:", e)
    }
}

function drawViewTrendChart(e) {
    const t = document.getElementById("viewTrendChart");
    if (t) {
        const n = t.getContext("2d");
        if (n.clearRect(0, 0, t.width, t.height), e && 0 !== e.length) {
            const a = t.width - 100,
                o = t.height - 100,
                d = Math.max(...e.map(e => e.count)),
                c = (n.strokeStyle = "rgba(255, 255, 255, 0.3)", n.lineWidth = 1, n.beginPath(), n.moveTo(50, 50), n.lineTo(50, t.height - 50), n.lineTo(t.width - 50, t.height - 50), n.stroke(), a / (e.length - 1 || 1));
            n.beginPath(), n.strokeStyle = "rgba(255, 255, 255, 0.8)", n.lineWidth = 2, e.forEach((e, a) => {
                var s = 50 + a * c;
                e = t.height - 50 - e.count / d * o, 0 === a ? n.moveTo(s, e) : n.lineTo(s, e)
            }), n.stroke(), e.forEach((e, a) => {
                a = 50 + a * c;
                var s = t.height - 50 - e.count / d * o;
                n.beginPath(), n.fillStyle = "rgba(255, 255, 255, 0.9)", n.arc(a, s, 4, 0, 2 * Math.PI), n.fill(), n.fillStyle = "rgba(255, 255, 255, 0.8)", n.font = "12px Arial", n.textAlign = "center", n.fillText(e.count, a, s - 10), n.fillStyle = "rgba(255, 255, 255, 0.6)", n.font = "10px Arial", e.date && "string" == typeof e.date && n.fillText(e.date.substring(5), a, t.height - 50 + 15)
            })
        } else n.font = "16px Arial", n.fillStyle = "rgba(255, 255, 255, 0.7)", n.textAlign = "center", n.fillText("暂无数据", t.width / 2, t.height / 2)
    }
}

function initAnalytics() {
    var e = document.getElementById("mostViewedLimit");
    e && e.addEventListener("change", loadMostViewedArticles), (e = document.getElementById("viewSourcesDays")) && e.addEventListener("change", loadViewSources), (e = document.getElementById("viewByCityDays")) && e.addEventListener("change", loadViewByCity), (e = document.getElementById("viewByIPDays")) && e.addEventListener("change", loadViewByIP), (e = document.getElementById("viewTrendDays")) && e.addEventListener("change", loadViewTrend), loadMostViewedArticles(), loadViewSources(), loadViewByCity(), loadViewByIP(), loadViewTrend()
}

function getStatusText(e) {
    return {
        published: "已发布",
        draft: "草稿",
        pending: "待审核"
    } [e] || e
}

function bindActionButtons() {
    document.querySelectorAll(".action-buttons button").forEach(e => {
        var t = e.cloneNode(!0);
        e.parentNode.replaceChild(t, e), t.addEventListener("click", async function() {
            const e = this.getAttribute("data-action"),
                t = this.getAttribute("data-id");
            if ("delete" === e || "delete-comment" === e || "delete-user" === e || "delete-category" === e) {
                currentAction = e, currentItemId = t;
                let n = "";
                "delete" === e ? n = `确定要删除文章 #${t} 吗？此操作不可撤销。` : "delete-comment" === e ? n = `确定要删除评论 #${t} 吗？此操作不可撤销。` : "delete-user" === e ? n = `确定要删除用户 #${t} 吗？此操作不可撤销。` : "delete-category" === e && (n = `确定要删除分类 #${t} 吗？此操作不可撤销。`), document.getElementById("confirmMessage").textContent = n, openModal("confirmModal")
            } else if ("edit" === e) try {
                    const e = localStorage.getItem("auth_token"),
                        o = {
                            "Content-Type": "application/json"
                        };
                    e && (o.Authorization = "Bearer " + e);
                    var n = await (await fetch("/api/admin/passages?id=" + t, {
                        headers: o
                    })).json();
                    if (n.success && n.data) {
                        await populateCategorySelect("editCategory", n.data.category || ""), document.getElementById("editTitle").value = n.data.title || "", document.getElementById("editAuthor").value = n.data.author || "管理员", document.getElementById("editContent").value = n.data.original_content || n.data.content || "", document.getElementById("editShowTitle").checked = !1 !== n.data.show_title, document.getElementById("editCoverImage").value = n.data.cover_image || "", document.getElementById("editStatus").value = n.data.status || "published", document.getElementById("editVisibility").value = n.data.visibility || "public";
                        const e = n.data.is_scheduled || !1;
                        document.getElementById("editIsScheduled").checked = e;
                        var a = document.getElementById("editPublishedAtGroup");
                        if (e) {
                            if (a.style.display = "block", n.data.published_at) {
                                const e = new Date(n.data.published_at),
                                    t = new Date(e.getTime() - 6e4 * e.getTimezoneOffset()).toISOString().slice(0, 16);
                                document.getElementById("editPublishedAt").value = t
                            }
                        } else a.style.display = "none", document.getElementById("editPublishedAt").value = "";
                        let o = [];
                        if (n.data.tags) {
                            const e = n.data.tags;
                            if (Array.isArray(e)) o = e;
                            else if ("string" == typeof e) try {
                                const t = JSON.parse(e);
                                o = Array.isArray(t) ? t : e.split(",").map(e => e.trim()).filter(e => e)
                            } catch (t) {
                                o = e.split(",").map(e => e.trim()).filter(e => e)
                            }
                        }
                        await populateTagSelector(o), document.getElementById("editForm").dataset.articleId = t, openModal("editModal")
                    } else showToast("获取文章详情失败：" + (n.message || "未知错误"), "error")
                } catch (e) {
                    console.error("获取文章详情失败:", e), showToast("获取文章详情失败，请稍后重试", "error")
                } else if ("upload" === e) document.getElementById("uploadAttachmentArticleId").textContent = "#" + t, document.getElementById("uploadAttachmentArticleId").dataset.articleId = t, document.getElementById("attachmentFile").value = "", document.getElementById("uploadAttachmentProgress").style.display = "none", document.getElementById("uploadAttachmentResult").style.display = "none", openModal("uploadAttachmentModal");
                else if ("view" === e) try {
                const e = localStorage.getItem("auth_token"),
                    n = {
                        "Content-Type": "application/json"
                    };
                e && (n.Authorization = "Bearer " + e);
                var o = await (await fetch("/api/admin/passages?id=" + t, {
                    headers: n
                })).json();
                o.success && o.data ? (document.getElementById("viewArticleId").textContent = "#" + o.data.id, document.getElementById("viewArticleTitle").textContent = o.data.title || "", document.getElementById("viewArticleAuthor").textContent = o.data.author || "管理员", document.getElementById("viewArticleStatus").textContent = getStatusText(o.data.status || "published"), document.getElementById("viewArticleDate").textContent = o.data.created_at || "", document.getElementById("viewArticleContent").textContent = o.data.content || "", openModal("viewArticleModal")) : showToast("获取文章详情失败：" + (o.message || "未知错误"), "error")
            } catch (e) {
                console.error("获取文章详情失败:", e), showToast("获取文章详情失败，请稍后重试", "error")
            } else if ("edit-user" === e) try {
                const e = localStorage.getItem("auth_token"),
                    n = {
                        "Content-Type": "application/json"
                    };
                e && (n.Authorization = "Bearer " + e);
                var d = await (await fetch("/api/admin/users/" + t, {
                    headers: n
                })).json();
                if (d.success && d.data) {
                    const e = d.data;
                    document.getElementById("editUserName").value = e.username || "", document.getElementById("editUserEmail").value = e.email || "", document.getElementById("editUserRole").value = e.role || "user", document.getElementById("editUserStatus").value = e.status || "active", document.getElementById("editUserPassword").value = "", document.getElementById("editUserForm").dataset.userId = t, openModal("editUserModal")
                } else showToast("获取用户详情失败：" + (d.message || "未知错误"), "error")
            } catch (e) {
                console.error("获取用户详情失败:", e), showToast("获取用户详情失败，请稍后重试", "error")
            } else if ("view-user" === e) try {
                    const e = localStorage.getItem("auth_token"),
                        n = {
                            "Content-Type": "application/json"
                        };
                    e && (n.Authorization = "Bearer " + e);
                    var c = await (await fetch("/api/admin/users/" + t, {
                        headers: n
                    })).json();
                    if (c.success && c.data) {
                        const e = c.data;
                        document.getElementById("viewUserId").textContent = "#" + e.id, document.getElementById("viewUserName").textContent = e.username || "", document.getElementById("viewUserEmail").textContent = e.email || "", document.getElementById("viewUserRole").textContent = e.role || "普通用户", document.getElementById("viewUserStatus").textContent = e.status || "正常", document.getElementById("viewUserDate").textContent = e.created_at || "", openModal("viewUserModal")
                    } else showToast("获取用户详情失败：" + (c.message || "未知错误"), "error")
                } catch (e) {
                    console.error("获取用户详情失败:", e), showToast("获取用户详情失败，请稍后重试", "error")
                } else if ("edit-comment" === e) alert("编辑评论 #" + t);
                else if ("view-comment" === e) {
                const e = this.closest("tr").querySelectorAll("td");
                6 <= e.length ? (document.getElementById("viewCommentId").textContent = e[0].textContent, document.getElementById("viewCommentContent").textContent = e[1].textContent, document.getElementById("viewCommentArticle").textContent = e[2].textContent, document.getElementById("viewCommentUser").textContent = e[3].textContent, document.getElementById("viewCommentDate").textContent = e[4].textContent, document.getElementById("viewCommentStatus").textContent = e[5].textContent.trim(), openModal("viewCommentModal")) : alert("查看评论 #${itemId} 的详细信息")
            } else if ("delete-tag" === e) currentAction = e, currentItemId = t, document.getElementById("confirmMessage").textContent = `确定要删除标签 #${t} 吗？此操作不可撤销。`, openModal("confirmModal");
            else if ("edit-tag" === e) try {
                const e = localStorage.getItem("auth_token"),
                    n = {
                        "Content-Type": "application/json"
                    };
                e && (n.Authorization = "Bearer " + e);
                var s = await (await fetch("/api/admin/tags?id=" + t, {
                    headers: n
                })).json();
                s.success && s.data ? (document.getElementById("tagModalTitle").textContent = "编辑标签", document.getElementById("tagName").value = s.data.name || "", document.getElementById("tagDescription").value = s.data.description || "", document.getElementById("tagColor").value = s.data.color || "#007bff", document.getElementById("tagCategory").value = s.data.category_id || 0, document.getElementById("tagSortOrder").value = s.data.sort_order || 0, document.getElementById("tagEnabled").checked = s.data.is_enabled, document.getElementById("tagForm").dataset.tagId = t, openModal("tagModal")) : showToast("获取标签详情失败：" + (s.message || "未知错误"), "error")
            } catch (e) {
                console.error("获取标签详情失败:", e), showToast("获取标签详情失败，请稍后重试", "error")
            } else if ("edit-category" === e) try {
                const e = localStorage.getItem("auth_token"),
                    n = {
                        "Content-Type": "application/json"
                    };
                e && (n.Authorization = "Bearer " + e);
                var r = await (await fetch("/api/admin/categories?id=" + t, {
                    headers: n
                })).json();
                r.success && r.data ? (document.getElementById("categoryModalTitle").textContent = "编辑分类", document.getElementById("categoryName").value = r.data.name || "", document.getElementById("categoryDescription").value = r.data.description || "", document.getElementById("categoryIcon").value = r.data.icon || "", document.getElementById("categorySortOrder").value = r.data.sort_order || 0, document.getElementById("categoryEnabled").checked = r.data.is_enabled, document.getElementById("categoryForm").dataset.categoryId = t, openModal("categoryModal")) : showToast("获取分类详情失败：" + (r.message || "未知错误"), "error")
            } catch (e) {
                console.error("获取分类详情失败:", e), showToast("获取分类详情失败，请稍后重试", "error")
            }
        })
    })
}
let lastScrollTop = 0,
    isNavHidden = !1;
const nav = document.getElementById("mainNav"),
    scrollIndicator = document.getElementById("scrollIndicator"),
    scrollProgress = document.getElementById("scrollProgress"),
    mainTitle = (nav.classList.add("scrolled-top"), window.addEventListener("scroll", function() {
        var e = window.pageYOffset || document.documentElement.scrollTop,
            t = e / (document.documentElement.scrollHeight - window.innerHeight) * 100;
        100 < e ? (scrollIndicator.classList.add("active"), scrollProgress.style.height = t + "%") : scrollIndicator.classList.remove("active"), e > lastScrollTop && 50 < e ? isNavHidden || (nav.classList.add("hidden"), isNavHidden = !0) : (e < lastScrollTop || e <= 50) && (isNavHidden && (nav.classList.remove("hidden"), isNavHidden = !1), 0 === e ? (nav.classList.add("scrolled-top"), nav.classList.remove("scrolled")) : (nav.classList.remove("scrolled-top"), nav.classList.add("scrolled"))), lastScrollTop = e
    }, {
        passive: !0
    }), window.addEventListener("load", function() {
        document.body.style.opacity = "0", document.body.style.transition = "opacity 0.5s ease", setTimeout(() => {
            document.body.style.opacity = "1"
        }, 100), showEmptyState("articlesTableBody", "暂无文章", 6), showEmptyState("usersTableBody", "暂无用户", 7), showEmptyState("commentsTableBody", "暂无评论", 6), fetchAdminData(), loadCategoriesAndTags(), document.querySelectorAll(".stat-card").forEach((e, t) => {
            e.style.opacity = "0", e.style.transform = "translateY(20px)", e.style.transition = "opacity 0.6s ease, transform 0.6s ease", setTimeout(() => {
                e.style.opacity = "1", e.style.transform = "translateY(0)"
            }, 200 + 50 * t)
        })
    }), document.getElementById("main-title"));

function openModal(e) {
    (e = document.getElementById(e)) && (e.classList.add("active"), document.body.style.overflow = "hidden")
}

function closeModal(e) {
    const t = document.getElementById(e);
    t && (t.classList.add("closing"), setTimeout(() => {
        t.classList.remove("active", "closing"), document.body.style.overflow = "auto"
    }, 300))
}
mainTitle && (mainTitle.addEventListener("mouseenter", function() {
    this.style.animationPlayState = "paused"
}), mainTitle.addEventListener("mouseleave", function() {
    this.style.animationPlayState = "running"
})), document.querySelectorAll(".tab-btn").forEach(e => {
    e.addEventListener("click", async function() {
        document.querySelectorAll(".tab-btn").forEach(e => {
            e.classList.remove("active")
        }), this.classList.add("active"), document.querySelectorAll(".tab-pane").forEach(e => {
            e.classList.remove("active")
        });
        var e = this.getAttribute("data-tab"),
            t = document.getElementById(e);
        t && (t.classList.add("active"), "tags" === e && await loadCategoriesAndTags(), "analytics" === e && initAnalytics(), "attachments" === e) && await loadAttachments()
    })
}), document.querySelectorAll("[data-modal]").forEach(e => {
    (e.classList.contains("modal-close") || e.hasAttribute("data-modal")) && e.addEventListener("click", function() {
        closeModal(this.getAttribute("data-modal"))
    })
}), document.getElementById("uploadArticleBtn").addEventListener("click", async () => {
    await populateTagSelectorForUpload(), await populateCategorySelectorForUpload(), openModal("uploadModal")
}), document.getElementById("newArticleBtn").addEventListener("click", async () => {
    await populateTagSelectorForNewArticle(), await populateCategorySelectorForNewArticle(), openModal("articleModal")
}), document.getElementById("addUserBtn").addEventListener("click", () => {
    openModal("userModal")
}), document.querySelectorAll(".tag-option").forEach(e => {
    e.addEventListener("click", function() {
        this.classList.toggle("selected")
    })
}), document.getElementById("addUploadTagBtn").addEventListener("click", async function() {
    var e, t, n, a = document.getElementById("uploadTagInput"),
        o = a.value.trim();
    o ? (e = document.getElementById("uploadTagSelector"), Array.from(e.querySelectorAll(".tag-option")).map(e => (e.dataset.tagName || e.textContent.trim()).toLowerCase()).includes(o.toLowerCase()) ? (showToast("标签已存在", "warning"), a.value = "") : (t = (t = ["#e74c3c", "#e67e22", "#f1c40f", "#2ecc71", "#1abc9c", "#3498db", "#9b59b6", "#34495e"])[Math.floor(Math.random() * t.length)], (n = document.createElement("div")).className = "tag-option selected", n.dataset.tagName = o, n.dataset.isNew = "true", n.innerHTML = `\n    <span style="display: inline-block; width: 12px; height: 12px; background-color: ${t}; border-radius: 2px; margin-right: 6px;"></span>\n    ${o}\n  `, n.addEventListener("click", function() {
        this.classList.toggle("selected")
    }), e.appendChild(n), a.value = "", showToast(`标签 "${o}" 已添加`, "success"))) : showToast("请输入标签名称", "warning")
}), document.getElementById("addUploadCategoryBtn").addEventListener("click", async function() {
    var e, t = document.getElementById("uploadCategoryInput"),
        n = t.value.trim();
    if (n) {
        const a = document.getElementById("uploadCategorySelector");
        Array.from(a.querySelectorAll(".category-option")).map(e => (e.dataset.categoryName || e.textContent.trim()).toLowerCase()).includes(n.toLowerCase()) ? (showToast("分类已存在", "warning"), t.value = "") : ((e = document.createElement("div")).className = "category-option selected", e.dataset.categoryName = n, e.dataset.isNew = "true", e.innerHTML = `\n    <span style="display: inline-block; width: 12px; height: 12px; background-color: #007bff; border-radius: 2px; margin-right: 6px;"></span>\n    ${n}\n  `, e.addEventListener("click", function() {
            this.classList.contains("selected") ? this.classList.remove("selected") : (a.querySelectorAll(".category-option").forEach(e => {
                e.classList.remove("selected")
            }), this.classList.add("selected"))
        }), a.querySelectorAll(".category-option").forEach(e => {
            e.classList.remove("selected")
        }), a.appendChild(e), t.value = "", showToast(`分类 "${n}" 已添加`, "success"))
    } else showToast("请输入分类名称", "warning")
});
const uploadArea = document.getElementById("uploadArea"),
    fileInput = document.getElementById("fileInput"),
    uploadPreview = document.getElementById("uploadPreview");
let selectedFiles = [];

function handleFiles(e) {
    for (let n = 0; n < e.length; n++) {
        const a = e[n];
        var t;
        10485760 < a.size ? showToast(`文件 ${a.name} 超过10MB限制`, "error") : (selectedFiles.push(a), (t = new FileReader).onload = function(e) {
            const t = document.createElement("div");
            if (t.className = "upload-item", t.dataset.fileIndex = selectedFiles.length - 1, a.type.startsWith("image/")) t.innerHTML = `\n          <img src="${e.target.result}" alt="${a.name}">\n          <button class="upload-remove">×</button>\n        `;
            else {
                const e = a.name.split(".").pop().toUpperCase();
                t.innerHTML = `\n          <div style="background:#f0f0f0; width:100%; height:100%; display:flex; flex-direction:column; align-items:center; justify-content:center; color:#666;">\n            <div style="font-size:2em;">📄</div>\n            <div style="font-size:0.8em; margin-top:5px; text-align:center; padding:0 5px;">${e}</div>\n          </div>\n          <button class="upload-remove">×</button>\n        `
            }
            t.querySelector(".upload-remove").addEventListener("click", function() {
                var e = parseInt(t.dataset.fileIndex);
                selectedFiles.splice(e, 1), t.remove()
            }), uploadPreview.appendChild(t)
        }, t.readAsDataURL(a))
    }
}

function readFileContent(e) {
    return new Promise((t, n) => {
        var a = new FileReader;
        a.onload = e => {
            t(e.target.result)
        }, a.onerror = () => {
            n(new Error("读取文件失败"))
        }, a.readAsText(e)
    })
}
uploadArea.addEventListener("click", () => {
    fileInput.click()
}), uploadArea.addEventListener("dragover", e => {
    e.preventDefault(), uploadArea.classList.add("dragover")
}), uploadArea.addEventListener("dragleave", () => {
    uploadArea.classList.remove("dragover")
}), uploadArea.addEventListener("drop", e => {
    e.preventDefault(), uploadArea.classList.remove("dragover"), handleFiles(e.dataTransfer.files)
}), fileInput.addEventListener("change", () => {
    handleFiles(fileInput.files)
}), document.getElementById("uploadForm").addEventListener("submit", async function(e) {
    e.preventDefault();
    const t = document.getElementById("uploadTitle").value.trim();
    if (t) {
        var n = document.getElementById("uploadAuthor").value.trim();
        if (n) {
            const s = document.querySelector("#uploadCategorySelector .category-option.selected"),
                r = s ? s.dataset.categoryName : "",
                i = [],
                l = (document.querySelectorAll("#uploadTagSelector .tag-option.selected").forEach(e => {
                    i.push(e.dataset.tagName)
                }), this.querySelector('button[type="submit"]')),
                m = l.textContent;
            l.textContent = "上传中...", l.disabled = !0;
            try {
                const s = selectedFiles,
                    u = document.getElementById("uploadContent").value.trim();
                if (0 !== s.length || u) {
                    let g = u;
                    if (0 < s.length && !u) {
                        const e = s[0];
                        g = await readFileContent(e)
                    }
                    if (g && 0 !== g.trim().length) {
                        let u = document.getElementById("uploadStatus").value,
                            h = document.getElementById("uploadYear").value,
                            y = document.getElementById("uploadMonth").value,
                            p = document.getElementById("uploadDay").value,
                            v = null;
                        if (h && y && p) {
                            const e = parseInt(h),
                                t = parseInt(y),
                                n = parseInt(p);
                            2020 <= e && e <= 2030 && 1 <= t && t <= 12 && 1 <= n && n <= 31 && (v = new Date(e, t - 1, n).toISOString())
                        }
                        var a = localStorage.getItem("auth_token"),
                            o = {
                                "Content-Type": "application/json"
                            },
                            d = (a && (o.Authorization = "Bearer " + a), {
                                title: t,
                                content: g,
                                author: n,
                                category: r,
                                tags: i.join(","),
                                status: u
                            }),
                            c = (v && (d.created_at = v), await (await fetch("/api/admin/passages", {
                                method: "POST",
                                headers: o,
                                body: JSON.stringify(d)
                            })).json());
                        if (c.success) {
                            let t = c.data.id,
                                n = 0,
                                o = 0,
                                d = [];
                            for (const c of s) try {
                                const e = new FormData,
                                    s = (e.append("file", c), e.append("passage_id", t), await fetch("/api/admin/attachments", {
                                        method: "POST",
                                        headers: {
                                            Authorization: "Bearer " + a
                                        },
                                        body: e
                                    })),
                                    r = await s.json();
                                r.success ? n++ : (o++, d.push(c.name + ": " + (r.message || "未知错误")))
                            } catch (e) {
                                o++, d.push(c.name + ": " + (e.message || "网络错误"))
                            }
                            l.textContent = "创建成功!", l.style.background = "rgba(255, 183, 122, 0.8)";
                            let r = "文章创建成功！";
                            0 < n && (r += ` 成功上传 ${n} 个附件`), 0 < o && (r += ` 失败 ${o} 个附件`), setTimeout(() => {
                                closeModal("uploadModal"), l.textContent = m, l.disabled = !1, l.style.background = "rgba(255, 183, 122, 0.8)", this.reset(), uploadPreview.innerHTML = "", selectedFiles = [], fetchAdminData(), showToast(r, 0 < o ? "warning" : "success")
                            }, 2e3)
                        } else l.textContent = m, l.disabled = !1, showToast("创建失败：" + (c.message || "未知错误"), "error")
                    } else showToast("文章内容不能为空", "warning"), l.textContent = m, l.disabled = !1
                } else showToast("请选择要上传的文件或输入文章内容", "warning"), l.textContent = m, l.disabled = !1
            } catch (e) {
                console.error("创建文章失败:", e), l.textContent = m, l.disabled = !1, showToast("创建失败，无法连接到服务器，请检查网络连接后重试", "error")
            }
        } else showToast("请输入作者名称", "warning"), document.getElementById("uploadAuthor").focus()
    } else showToast("请输入文章标题", "warning"), document.getElementById("uploadTitle").focus()
}), document.getElementById("articleForm").addEventListener("submit", async function(e) {
    e.preventDefault();
    var t = document.getElementById("articleTitle").value;
    if (t) {
        const a = this.querySelector('button[type="submit"]'),
            o = a.textContent;
        a.textContent = "保存中...", a.disabled = !0;
        try {
            const e = localStorage.getItem("auth_token"),
                d = {
                    "Content-Type": "application/json"
                };
            e && (d.Authorization = "Bearer " + e);
            var n = await (await fetch("/api/admin/passages", {
                method: "POST",
                headers: d,
                body: JSON.stringify({
                    title: t,
                    content: document.getElementById("articleContent").value,
                    author: document.getElementById("articleAuthor").value,
                    category: document.getElementById("articleCategory").value,
                    tags: document.getElementById("articleTags").value,
                    cover_image: document.getElementById("articleCoverImage").value
                })
            })).json();
            n.success ? (a.textContent = "保存成功!", a.style.background = "rgba(255, 183, 122, 0.8)", setTimeout(() => {
                closeModal("articleModal"), a.textContent = o, a.disabled = !1, a.style.background = "rgba(255, 183, 122, 0.8)", this.reset(), fetchAdminData(), showToast("文章创建成功！", "success")
            }, 2e3)) : (a.textContent = o, a.disabled = !1, showToast("保存失败：" + (n.message || "未知错误"), "error"))
        } catch (e) {
            console.error("保存文章失败:", e), a.textContent = o, a.disabled = !1, showToast("保存失败，请稍后重试", "error")
        }
    } else showToast("请输入文章标题", "warning")
}), document.getElementById("editForm").addEventListener("submit", async function(e) {
    e.preventDefault();
    var t = this.dataset.articleId;
    if (t) {
        const a = this.querySelector('button[type="submit"]'),
            o = a.textContent;
        a.textContent = "保存中...", a.disabled = !0;
        try {
            const e = localStorage.getItem("auth_token"),
                d = {
                    "Content-Type": "application/json"
                };
            e && (d.Authorization = "Bearer " + e);
            let c = document.getElementById("editIsScheduled").checked,
                s = null;
            if (c) {
                const e = document.getElementById("editPublishedAt").value;
                e && (s = new Date(e).toISOString())
            }
            var n = await (await fetch("/api/admin/passages?id=" + t, {
                method: "PUT",
                headers: d,
                body: JSON.stringify({
                    title: document.getElementById("editTitle").value,
                    content: document.getElementById("editContent").value,
                    author: document.getElementById("editAuthor").value,
                    category: document.getElementById("editCategory").value,
                    show_title: document.getElementById("editShowTitle").checked,
                    tags: document.getElementById("editTags").value,
                    status: document.getElementById("editStatus").value,
                    visibility: document.getElementById("editVisibility").value,
                    is_scheduled: c,
                    published_at: s,
                    cover_image: document.getElementById("editCoverImage").value || void 0
                })
            })).json();
            n.success ? (a.textContent = "保存成功!", a.style.background = "rgba(255, 183, 122, 0.8)", setTimeout(() => {
                closeModal("editModal"), a.textContent = o, a.disabled = !1, a.style.background = "rgba(255, 183, 122, 0.8)", fetchAdminData(), showToast("文章修改已保存！", "success")
            }, 2e3)) : (a.textContent = o, a.disabled = !1, showToast("保存失败：" + (n.message || "未知错误"), "error"))
        } catch (e) {
            console.error("保存文章失败:", e), a.textContent = o, a.disabled = !1, showToast("保存失败，请稍后重试", "error")
        }
    } else showToast("无法确定要编辑的文章", "error")
}), document.getElementById("editIsScheduled").addEventListener("change", function(e) {
    const t = document.getElementById("editPublishedAtGroup"),
        n = document.getElementById("editPublishedAt");
    if (e.target.checked) {
        if (t.style.display = "block", !n.value) {
            const e = new Date,
                t = (e.setDate(e.getDate() + 1), new Date(e.getTime() - 6e4 * e.getTimezoneOffset()).toISOString().slice(0, 16));
            n.value = t
        }
    } else t.style.display = "none", n.value = ""
}), document.getElementById("userForm").addEventListener("submit", async function(e) {
    e.preventDefault();
    const t = this.querySelector('button[type="submit"]'),
        n = t.textContent;
    t.textContent = "创建中...", t.disabled = !0;
    var a = document.getElementById("userName").value.trim(),
        o = document.getElementById("userEmail").value.trim(),
        d = document.getElementById("userPassword").value,
        c = document.getElementById("userRole").value;
    try {
        const e = await fetch("/api/register", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    ...getAuthHeaders()
                },
                body: JSON.stringify({
                    username: a,
                    email: o,
                    password: d,
                    role: c
                })
            }),
            t = await e.json();
        t.success ? (showToast("用户创建成功！", "success"), closeModal("userModal"), this.reset(), fetchAdminData(currentPage, 10, currentUserPage, 10)) : showToast(t.message || "用户创建失败", "error")
    } catch (e) {
        console.error("创建用户失败:", e), showToast("创建用户失败，请重试", "error")
    } finally {
        t.textContent = n, t.disabled = !1
    }
}), document.getElementById("editUserForm").addEventListener("submit", async function(e) {
    e.preventDefault();
    var t = this.dataset.userId;
    if (t) {
        const d = this.querySelector('button[type="submit"]'),
            c = d.textContent;
        d.textContent = "保存中...", d.disabled = !0;
        try {
            const e = localStorage.getItem("auth_token"),
                s = {
                    "Content-Type": "application/json"
                };
            e && (s.Authorization = "Bearer " + e);
            var n = {
                    username: document.getElementById("editUserName").value,
                    email: document.getElementById("editUserEmail").value,
                    role: document.getElementById("editUserRole").value,
                    status: document.getElementById("editUserStatus").value
                },
                a = document.getElementById("editUserPassword").value,
                o = (a && (n.password = a), await (await fetch("/api/admin/users/" + t, {
                    method: "PATCH",
                    headers: s,
                    body: JSON.stringify(n)
                })).json());
            o.success ? (d.textContent = "保存成功!", d.style.background = "rgba(255, 183, 122, 0.8)", setTimeout(() => {
                closeModal("editUserModal"), d.textContent = c, d.disabled = !1, d.style.background = "rgba(255, 183, 122, 0.8)", fetchAdminData(), showToast("用户修改已保存！", "success")
            }, 2e3)) : (d.textContent = c, d.disabled = !1, showToast("保存失败：" + (o.message || "未知错误"), "error"))
        } catch (e) {
            console.error("保存用户失败:", e), d.textContent = c, d.disabled = !1, showToast("保存失败，请稍后重试", "error")
        }
    } else showToast("无法确定要编辑的用户", "error")
}), document.getElementById("categoryForm").addEventListener("submit", async function(e) {
    e.preventDefault();
    const t = this.dataset.categoryId,
        n = this.querySelector('button[type="submit"]'),
        a = n.textContent;
    n.textContent = "保存中...", n.disabled = !0;
    try {
        const e = localStorage.getItem("auth_token"),
            d = {
                "Content-Type": "application/json"
            };
        e && (d.Authorization = "Bearer " + e);
        let c = {
                name: document.getElementById("categoryName").value,
                description: document.getElementById("categoryDescription").value,
                icon: document.getElementById("categoryIcon").value,
                sort_order: parseInt(document.getElementById("categorySortOrder").value) || 0,
                is_enabled: document.getElementById("categoryEnabled").checked
            },
            s = "/api/admin/categories",
            r = "POST";
        t && (s += "?id=" + t, r = "PUT");
        var o = await (await fetch(s, {
            method: r,
            headers: d,
            body: JSON.stringify(c)
        })).json();
        o.success ? (n.textContent = "保存成功!", n.style.background = "rgba(255, 183, 122, 0.8)", setTimeout(() => {
            closeModal("categoryModal"), n.textContent = a, n.disabled = !1, n.style.background = "rgba(255, 183, 122, 0.8)", this.reset(), delete this.dataset.categoryId, loadCategoriesAndTags(), showToast(t ? "分类修改已保存！" : "分类创建成功！", "success")
        }, 2e3)) : (n.textContent = a, n.disabled = !1, showToast("保存失败：" + (o.message || "未知错误"), "error"))
    } catch (e) {
        console.error("保存分类失败:", e), n.textContent = a, n.disabled = !1, showToast("保存失败，请稍后重试", "error")
    }
}), document.getElementById("tagForm").addEventListener("submit", async function(e) {
    e.preventDefault();
    const t = this.dataset.tagId,
        n = this.querySelector('button[type="submit"]'),
        a = n.textContent;
    n.textContent = "保存中...", n.disabled = !0;
    try {
        const e = localStorage.getItem("auth_token"),
            d = {
                "Content-Type": "application/json"
            };
        e && (d.Authorization = "Bearer " + e);
        let c = {
                name: document.getElementById("tagName").value,
                description: document.getElementById("tagDescription").value,
                color: document.getElementById("tagColor").value,
                category_id: parseInt(document.getElementById("tagCategory").value) || 0,
                sort_order: parseInt(document.getElementById("tagSortOrder").value) || 0,
                is_enabled: document.getElementById("tagEnabled").checked
            },
            s = "/api/admin/tags",
            r = "POST";
        t && (s += "?id=" + t, r = "PUT");
        var o = await (await fetch(s, {
            method: r,
            headers: d,
            body: JSON.stringify(c)
        })).json();
        o.success ? (n.textContent = "保存成功!", n.style.background = "rgba(255, 183, 122, 0.8)", setTimeout(() => {
            closeModal("tagModal"), n.textContent = a, n.disabled = !1, n.style.background = "rgba(255, 183, 122, 0.8)", this.reset(), delete this.dataset.tagId, loadCategoriesAndTags(), showToast(t ? "标签修改已保存！" : "标签创建成功！", "success")
        }, 2e3)) : (n.textContent = a, n.disabled = !1, showToast("保存失败：" + (o.message || "未知错误"), "error"))
    } catch (e) {
        console.error("保存标签失败:", e), n.textContent = a, n.disabled = !1, showToast("保存失败，请稍后重试", "error")
    }
});
let currentAction = null,
    currentItemId = null,
    selectedAttachments = new Set;
async function handleBatchDelete(e, t) {
    let n = t.split(",").map(e => parseInt(e.trim())),
        a = "",
        o = "",
        d = null;
    switch (e) {
        case "batch-delete-comments":
            a = "/api/admin/comments/batch-delete", o = "批量删除评论成功", d = () => {
                clearCommentSelection(), fetchAdminData(currentPage, currentLimit, currentUserPage, currentUserLimit, currentCommentsPage, currentCommentsLimit)
            };
            break;
        case "batch-delete-categories":
            a = "/api/admin/categories/batch-delete", o = "批量删除分类成功", d = () => {
                clearCategorySelection(), loadCategoriesAndTags()
            };
            break;
        case "batch-delete-tags":
            a = "/api/admin/tags/batch-delete", o = "批量删除标签成功", d = () => {
                clearTagSelection(), loadCategoriesAndTags()
            };
            break;
        case "batch-delete-users":
            a = "/api/admin/users/batch-delete", o = "批量删除用户成功", d = () => {
                clearUserSelection(), fetchAdminData(currentPage, 10, currentUserPage, 10)
            };
            break;
        case "batch-delete-articles":
            a = "/api/admin/passages/batch-delete", o = "批量删除文章成功", d = () => {
                clearSelection(), fetchAdminData(currentPage, 10)
            };
            break;
        default:
            return
    }
    try {
        const e = await fetch(a, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    ...getAuthHeaders()
                },
                body: JSON.stringify({
                    ids: n
                })
            }),
            t = await e.json();
        t.success ? (closeModal("confirmModal"), showToast(t.message || o, "success"), d && d()) : showToast(t.message || "批量删除失败", "error")
    } catch (e) {
        console.error("批量删除失败:", e), showToast("批量删除失败，请重试", "error")
    }
}
document.getElementById("confirmAction").addEventListener("click", async function() {
    if (currentAction && currentItemId)
        if (currentAction.startsWith("batch-delete-")) await handleBatchDelete(currentAction, currentItemId);
        else {
            var e = localStorage.getItem("auth_token"),
                t = {
                    "Content-Type": "application/json"
                };
            e && (t.Authorization = "Bearer " + e);
            try {
                let a = "";
                if ("delete" === currentAction) a = "/api/admin/passages?id=" + currentItemId;
                else if ("delete-comment" === currentAction) a = "/api/admin/comments/" + currentItemId;
                else if ("delete-user" === currentAction) a = "/api/admin/users/" + currentItemId;
                else if ("delete-category" === currentAction) a = "/api/admin/categories?id=" + currentItemId;
                else if ("delete-tag" === currentAction) a = "/api/admin/tags/" + currentItemId;
                else if ("delete-main-card" === currentAction) a = "/api/about/main-cards/delete?id=" + currentItemId;
                else if ("delete-sub-card" === currentAction) a = "/api/about/sub-cards/delete?id=" + currentItemId;
                else if ("delete-attachment" === currentAction) a = "/api/admin/attachments/" + currentItemId;
                else if ("batch-delete-attachment" === currentAction) {
                    let t = currentItemId.split(","),
                        n = 0,
                        a = 0;
                    for (const o of t) try {
                        (await (await fetch("/api/admin/attachments/" + o, {
                            method: "DELETE"
                        })).json()).success ? n++ : a++
                    } catch (e) {
                        console.error("删除失败:", e), a++
                    }
                    return closeModal("confirmModal"), 0 < n && showToast(`成功删除 ${n} 个附件`, "success"), 0 < a && showToast(a + " 个附件删除失败", "error"), selectedAttachments.clear(), updateBatchActions(), void loadAttachments()
                }
                var n = await (await fetch(a, {
                    method: "DELETE",
                    headers: t
                })).json();
                n.success ? (closeModal("confirmModal"), showToast("删除成功！", "success"), ("delete-category" === currentAction || "delete-tag" === currentAction ? loadCategoriesAndTags : "delete-main-card" === currentAction ? (loadMainCards(), loadSubCards) : "delete-sub-card" === currentAction ? loadSubCards : "delete-attachment" === currentAction ? (selectedAttachments.delete(currentItemId), updateBatchActions(), loadAttachments) : fetchAdminData)()) : showToast("删除失败：" + (n.message || "未知错误"), "error")
            } catch (e) {
                console.error("删除失败:", e), alert("删除失败，请稍后重试")
            }
        }
}), document.querySelectorAll(".modal").forEach(e => {
    e.addEventListener("click", function(e) {
        e.target === this && closeModal(this.id)
    })
}), document.addEventListener("keydown", function(e) {
    "Escape" === e.key && document.querySelectorAll(".modal.active").forEach(e => {
        closeModal(e.id)
    })
});
