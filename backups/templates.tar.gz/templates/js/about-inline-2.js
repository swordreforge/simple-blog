function closeModalWithAnimation(e) {
      e &&
        (e.classList.add('closing'),
        setTimeout(() => {
          e.classList.remove('active', 'closing');
        }, 300));
    }
    function closeAllModals() {
      document.querySelectorAll('.modal.active').forEach(e => {
        closeModalWithAnimation(e);
      });
    }
    document.addEventListener('DOMContentLoaded', function () {
      fetch('/api/settings/appearance')
        .then(e => e.json())
        .then(e => {
          function o() {
            const o =
              window.innerWidth <= 768 && e.mobile_background_image
                ? e.mobile_background_image
                : e.background_image;
            o && (document.body.style.backgroundImage = `url('${o}')`);
          }
          (localStorage.setItem('appearanceSettings', JSON.stringify(e)),
            e.dark_mode_enabled && document.documentElement.classList.add('dark-mode'),
            (e.navbar_glass_color ||
              e.card_glass_color ||
              e.footer_glass_color ||
              e.navbar_text_color) &&
              (document.documentElement.style.setProperty(
                '--navbar-glass-color',
                e.navbar_glass_color || 'rgba(255, 255, 255, 0.85)'
              ),
              document.documentElement.style.setProperty(
                '--navbar-text-color',
                e.navbar_text_color || 'rgba(255, 255, 255, 0.9)'
              ),
              document.documentElement.style.setProperty(
                '--card-glass-color',
                e.card_glass_color || 'rgba(255, 255, 255, 0.75)'
              ),
              document.documentElement.style.setProperty(
                '--footer-glass-color',
                e.footer_glass_color || 'rgba(255, 255, 255, 0.9)'
              )),
            o(),
            window.addEventListener('resize', o));
        })
        .catch(e => {
          console.error('加载外观设置失败:', e);
        });
      const e = document.getElementById('userCenterToggle'),
        o = document.getElementById('userCenterModal'),
        t = o ? o.querySelector('.modal-close') : null;
      if (e && o) {
        (e.addEventListener('click', function (e) {
          (e.stopPropagation(), closeAllModals(), o.classList.add('active'));
        }),
          t &&
            t.addEventListener('click', function () {
              closeModalWithAnimation(o);
            }));
        const n = o.querySelector('.modal-content');
        (n &&
          n.addEventListener('click', function (e) {
            e.stopPropagation();
          }),
          o.addEventListener('click', function () {
            closeModalWithAnimation(o);
          }));
      }
      document.addEventListener('keydown', function (e) {
        'Escape' === e.key && closeAllModals();
      });
    });